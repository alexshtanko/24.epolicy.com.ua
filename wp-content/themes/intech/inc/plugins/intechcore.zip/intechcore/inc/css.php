<?php
if ( !function_exists( 'intech_google_font_url' ) ):
/**
 * Register Google fonts.
 *
 * @return string Google fonts URL for the theme.
 */
    function intech_google_font_url() {
        if ( is_cs_framework_active() ) {
            $fonts_url = '';
            $fonts = array();
            if ( is_cs_framework_active() ) {
                $intech_body_fonts_variant = cs_get_option( 'intech_body_fonts_variant' );
                $intech_body_fonts_variant_process = implode( ',', $intech_body_fonts_variant );
                $intech_body_subsets = ':' . esc_html( $intech_body_fonts_variant_process ) . '';
                $intech_body_fonts = cs_get_option( 'intech_body_fonts' )['family'];
                $intech_body_fonts .= $intech_body_subsets;
                $intech_haddings_fonts = cs_get_option( 'intech_haddings_fonts' )['family'];
                $intech_haddings_fonts_variant = cs_get_option( 'intech_haddings_fonts_variant' );
                $intech_haddings_fonts_variant_process = implode( ',', $intech_haddings_fonts_variant );
                $intech_hadding_subsets = ':' . esc_html( $intech_haddings_fonts_variant_process ) . '';
                $intech_haddings_fonts .= $intech_hadding_subsets;
                $intech_menu_fonts = cs_get_option( 'intech_menu_fonts' )['family'];
                $intech_menu_fonts_variant = cs_get_option( 'intech_menu_fonts_variant' );
                $intech_menu_fonts_variant_process = implode( ',', $intech_menu_fonts_variant );
                $intech_menu_subsets = ':' . esc_html( $intech_menu_fonts_variant_process ) . '';
                $intech_menu_fonts .= $intech_menu_subsets;
            }
            if ( 'off' !== esc_html_x( 'on', 'Google font: on or off', 'intechcore' ) ) {
                $fonts[] = $intech_body_fonts;
            }
            if ( 'off' !== esc_html_x( 'on', 'Google font: on or off', 'intechcore' ) ) {
                $fonts[] = $intech_haddings_fonts;
            }
            if ( 'off' !== esc_html_x( 'on', 'Google font: on or off', 'intechcore' ) ) {
                $fonts[] = $intech_menu_fonts;
            }
            if ( $fonts ) {
                $fonts_url = add_query_arg( array(
                    'family' => urlencode( implode( '|', $fonts ) ),
                ), 'https://fonts.googleapis.com/css' );
            }
            return $fonts_url;
        }
    }
endif;

/**
 * Enqueue scripts and styles.
 */
function intech_google_font_script() {
    wp_enqueue_style( 'intech-google-fonts', intech_google_font_url(), array(), null );
}
add_action( 'wp_enqueue_scripts', 'intech_google_font_script' );

function intech_custom_css() {
    wp_enqueue_style(
        'intech-custom-style', get_template_directory_uri() . '/assets/css/custom-style.css', array( 'bootstrap', 'intech-theme', 'intechcore', 'intech-typrography', 'intech-default', 'sm-simple' )
    );

    $intech_page_id = get_the_ID();
    if ( get_post_meta( $intech_page_id, 'intech_page_meta_options', true ) ) {
        $intech_page_meta = get_post_meta( $intech_page_id, 'intech_page_meta_options', true );
    } else {
        $intech_page_meta = array();
    }

    if ( is_cs_framework_active() ) {
        $intech_body_fonts = cs_get_option( 'intech_body_fonts' )['family'];
        $intech_body_fonts_variant = cs_get_option( 'intech_body_fonts' )['variant'];
        $intech_haddings_fonts = cs_get_option( 'intech_haddings_fonts' )['family'];
        $intech_haddings_fonts_variant = cs_get_option( 'intech_haddings_fonts' )['variant'];
        $intech_menu_fonts = cs_get_option( 'intech_menu_fonts' )['family'];
        $intech_menu_fonts_variant = cs_get_option( 'intech_menu_fonts' )['variant'];
        if ( array_key_exists( 'intech_page_header_select', $intech_page_meta ) ) {
            $intech_page_header_select = $intech_page_meta['intech_page_header_select'];
        }
        if ( array_key_exists( 'intech_header_top_padding', $intech_page_meta ) ) {
            $intech_header_top_padding = $intech_page_meta['intech_header_top_padding'];
        }
        if ( array_key_exists( 'intech_header_top_bg', $intech_page_meta ) ) {
            $intech_header_top_bg = $intech_page_meta['intech_header_top_bg'];
        }
        if ( array_key_exists( 'intech_main_header_bg', $intech_page_meta ) ) {
            $intech_main_header_bg = $intech_page_meta['intech_main_header_bg'];
        }
        if ( array_key_exists( 'intech_logo_bg_color', $intech_page_meta ) ) {
            $intech_logo_bg_color = $intech_page_meta['intech_logo_bg_color'];
        }
        if ( array_key_exists( 'intech_logo_bg_color5', $intech_page_meta ) ) {
            $intech_logo_bg_color5 = $intech_page_meta['intech_logo_bg_color5'];
        }
        if ( array_key_exists( 'intech_menu5_color', $intech_page_meta ) ) {
            $intech_menu5_color = $intech_page_meta['intech_menu5_color'];
        }
        if ( array_key_exists( 'intech_menu5_hcolor', $intech_page_meta ) ) {
            $intech_menu5_hcolor = $intech_page_meta['intech_menu5_hcolor'];
        }
        if ( array_key_exists( 'intech_logo_hedigh', $intech_page_meta ) ) {
            $intech_logo_hedigh = $intech_page_meta['intech_logo_hedigh'];
        }
        if ( array_key_exists( 'intech_logo_hedigh5', $intech_page_meta ) ) {
            $intech_logo_hedigh5 = $intech_page_meta['intech_logo_hedigh5'];
        }
        if ( array_key_exists( 'intech_logo_widght', $intech_page_meta ) ) {
            $intech_logo_widght = $intech_page_meta['intech_logo_widght'];
        }
        if ( array_key_exists( 'intech_logo_widght5', $intech_page_meta ) ) {
            $intech_logo_widght5 = $intech_page_meta['intech_logo_widght5'];
        }

        $intech_breadcrumb_upload_image_enable = cs_get_option( 'intech_breadcrumb_upload_image_enable' );
        $intech_breadcrumb_image = cs_get_option( 'intech_breadcrumb_image' );
        $intech_breadcrumb_image_array = wp_get_attachment_image_src( $intech_breadcrumb_image, 'full', false );
        $intech_breadcrumb_bg_repeat = cs_get_option( 'intech_breadcrumb_bg_repeat' );
        $intech_breadcrumb_bg_attach = cs_get_option( 'intech_breadcrumb_bg_attach' );
        $intech_breadcrumb_bg_position = cs_get_option( 'intech_breadcrumb_bg_position' );
        $intech_breadcrumb_bg_oparicty = cs_get_option( 'intech_breadcrumb_bg_oparicty' );
        $intech_breadcrumb_bg_padding = cs_get_option( 'intech_breadcrumb_bg_padding' );
        $intech_custom_page_padding = cs_get_option( 'intech_custom_page_padding' );
        $intech_breadcrumb_bg_size = cs_get_option( 'intech_breadcrumb_bg_size' );
        $intech_page_title_alinement = cs_get_option( 'intech_page_title_alinement' );
        $intech_custom_page_title_size = cs_get_option( 'intech_custom_page_title_size' );
        $intech_custom_page_title_color = cs_get_option( 'intech_custom_page_title_color' );
        $intech_page_title_f_width = cs_get_option( 'intech_page_title_f_width' );
        $intech_page_title_text_transform = cs_get_option( 'intech_page_title_text_transform' );
        $intech_copyright_bg = cs_get_option( 'intech_copyright_bg' );
        $intech_copyright_text = cs_get_option( 'intech_copyright_text' );
        $intech_copyright_link = cs_get_option( 'intech_copyright_link' );
        $intech_copyright_linkh = cs_get_option( 'intech_copyright_linkh' );
        $intech_fotter_bg = cs_get_option( 'intech_fotter_bg' );
        $intech_ft_title_color = cs_get_option( 'intech_ft_title_color' );
        $intech_ft_title_line_color = cs_get_option( 'intech_ft_title_line_color' );
        $intech_ft_icon_color = cs_get_option( 'intech_ft_icon_color' );
        $intech_ft_text_color = cs_get_option( 'intech_ft_text_color' );
        $intech_ft_link_color = cs_get_option( 'intech_ft_link_color' );
        $intech_ft_linkh_color = cs_get_option( 'intech_ft_linkh_color' );
        $intech_theme_color = cs_get_option( 'intech_theme_color' );
        $intech_theme_secondary_color = cs_get_option( 'intech_theme_secondary_color' );
        $intech_fotter2_bg = cs_get_option( 'intech_fotter2_bg' );
        $intech_fotter2_animation_bg = cs_get_option( 'intech_fotter2_animation_bg' );
        $intech_custom_css_add = '
            body,p {font-family:' . esc_html( $intech_body_fonts ) . ';font-weight:' . esc_attr( $intech_body_fonts_variant ) . '}
            h1,h2,h3,h4,h5,h6 {font-family:' . esc_html( $intech_haddings_fonts ) . ';font-weight:' . esc_attr( $intech_haddings_fonts_variant ) . '}
            .sm-simple a{font-family:' . esc_html( $intech_menu_fonts ) . ';font-weight:' . esc_attr( $intech_menu_fonts_variant ) . '}
        ';
    }

    if ( is_cs_framework_active() ) {

        if ( array_key_exists( 'intech_page_header_select', $intech_page_meta ) ) {
            if ( !empty( $intech_page_header_select == '2' ) ) {
                $intech_custom_css_add .= '.header-area.header2 .header-main-area{background-color:' . esc_attr( $intech_main_header_bg ) . '}';
                $intech_custom_css_add .= '.header-area.header2 .header-top{background-color:' . esc_attr( $intech_header_top_bg ) . '}';
                $intech_custom_css_add .= '.header-area.header2 .header-top{padding:' . esc_attr( $intech_header_top_padding ) . '}';
            }
            if ( !empty( $intech_page_header_select == '4' ) ) {
                $intech_custom_css_add .= '.header-area.header4 .theme-logo a{min-height:' . esc_attr( $intech_logo_hedigh ) . '}';
                $intech_custom_css_add .= '.header-area.header4 .theme-logo a{min-width:' . esc_attr( $intech_logo_widght ) . '}';
                $intech_custom_css_add .= '.header-area.header4 .theme-logo a{background-color:' . esc_attr( $intech_logo_bg_color ) . '}';
            }
            if ( !empty( $intech_page_header_select == '5' ) ) {
                $intech_custom_css_add .= '.header-area.header5 .theme-logo a{min-height:' . esc_attr( $intech_logo_hedigh5 ) . '}';
                $intech_custom_css_add .= '.header-area.header5 .theme-logo a{min-width:' . esc_attr( $intech_logo_widght5 ) . '}';
                $intech_custom_css_add .= '.header-area.header5 .theme-logo a{background-color:' . esc_attr( $intech_logo_bg_color5 ) . '}';
                $intech_custom_css_add .= '.header-area.header5 #navmenu>ul>li>a,.header-area.header5 .header-quote-icon i:before,.header-area.header5 .header-quote-content h4,.header-area.header5 .header-quote-content h2{color:' . esc_attr( $intech_menu5_color ) . '}';
                $intech_custom_css_add .= '.header-area.header5 #navmenu>ul>li>a:hover,.header-area.header5 .header-quote a:hover .header-quote-icon i:before, .header-area.header5 .header-quote a:hover h4,.header-area.header5 .header-quote a:hover h2{color:' . esc_attr( $intech_menu5_hcolor ) . '}';
            }
            
        }
        if ( array_key_exists( 'intech_header6_bg', $intech_page_meta ) ) {
            $intech_header6_bg = $intech_page_meta['intech_header6_bg'];
        }
        if ( array_key_exists( 'intech_header6_btn_bg', $intech_page_meta ) ) {
            $intech_header6_btn_bg = $intech_page_meta['intech_header6_btn_bg'];
        }
        if ( array_key_exists( 'intech_header6_btn_hbg', $intech_page_meta ) ) {
            $intech_header6_btn_hbg = $intech_page_meta['intech_header6_btn_hbg'];
        }
        if ( array_key_exists( 'intech_header6_btn_border_c', $intech_page_meta ) ) {
            $intech_header6_btn_border_c = $intech_page_meta['intech_header6_btn_border_c'];
        }
        if ( array_key_exists( 'intech_header6_btn_border_hc', $intech_page_meta ) ) {
            $intech_header6_btn_border_hc = $intech_page_meta['intech_header6_btn_border_hc'];
        }
        if ( array_key_exists( 'intech_header6_btn_text_c', $intech_page_meta ) ) {
            $intech_header6_btn_text_c = $intech_page_meta['intech_header6_btn_text_c'];
        }
        if ( array_key_exists( 'intech_header6_btn_text_hc', $intech_page_meta ) ) {
            $intech_header6_btn_text_hc = $intech_page_meta['intech_header6_btn_text_hc'];
        }
        if ( array_key_exists( 'intech_header6_position', $intech_page_meta ) ) {
            $intech_header6_position = $intech_page_meta['intech_header6_position'];
        }
        if ( array_key_exists( 'intech_header6_menu_c', $intech_page_meta ) ) {
            $intech_header6_menu_c = $intech_page_meta['intech_header6_menu_c'];
        }
        if ( array_key_exists( 'intech_header6_menu_hc', $intech_page_meta ) ) {
            $intech_header6_menu_hc = $intech_page_meta['intech_header6_menu_hc'];
        }
        if ( array_key_exists( 'intech_header6_sticky_bg', $intech_page_meta ) ) {
            $intech_header6_sticky_bg = $intech_page_meta['intech_header6_sticky_bg'];
        }

        if ( array_key_exists( 'intech_page_header_select', $intech_page_meta ) &&  !empty( $intech_page_header_select == '6' ) )  {
            if(!empty($intech_header6_bg)){
                $intech_custom_css_add .= '.header-area.header6{background-color:' . esc_attr( $intech_header6_bg ) . '}';
            }
            if(!empty($intech_header6_sticky_bg)){
                $intech_custom_css_add .= '.header-area.header6 .header-main-area.on{background-color:' . esc_attr( $intech_header6_sticky_bg ) . '}';
            }
            if(!empty($intech_header6_btn_bg)){
                $intech_custom_css_add .= '.quote-btn-2{background-color:' . esc_attr( $intech_header6_btn_bg ) . '}';
            }
            if(!empty($intech_header6_btn_hbg)){
                $intech_custom_css_add .= '.quote-btn-2:hover{background-color:' . esc_attr( $intech_header6_btn_hbg ) . '}';
            }
            if(!empty($intech_header6_btn_border_c)){
                $intech_custom_css_add .= '.quote-btn-2{border-color:' . esc_attr( $intech_header6_btn_border_c ) . '}';
            }
            if(!empty($intech_header6_btn_border_hc)){
                $intech_custom_css_add .= '.quote-btn-2:hover{border-color:' . esc_attr( $intech_header6_btn_border_hc ) . '}';
            }
            if(!empty($intech_header6_btn_text_c)){
                $intech_custom_css_add .= '.quote-btn-2{color:' . esc_attr( $intech_header6_btn_text_c ) . '}';
            } 
            if(!empty($intech_header6_btn_text_hc)){
                $intech_custom_css_add .= '.quote-btn-2:hover{color:' . esc_attr( $intech_header6_btn_text_hc ) . '}';
            }
            if(!empty($intech_header6_position)){
                $intech_custom_css_add .= '.header-area.header6{position:' . esc_attr( $intech_header6_position ) . '}';
            }
            if(!empty($intech_header6_menu_c)){
                $intech_custom_css_add .= '.header-area.header6 #navmenu>ul>li>a{color:' . esc_attr( $intech_header6_menu_c ) . '}';
            }
            if(!empty($intech_header6_menu_hc)){
                $intech_custom_css_add .= '.header-area.header6 #navmenu>ul>li>a:hover{color:' . esc_attr( $intech_header6_menu_hc ) . '}';
            }
        }else{
            $intech_op_header6_bg = cs_get_option( 'intech_op_header6_bg' );
            $intech_op_header6_btn_bg = cs_get_option( 'intech_op_header6_btn_bg' );
            $intech_op_header6_btn_hbg = cs_get_option( 'intech_op_header6_btn_hbg' );
            $intech_op_header6_btn_border_c = cs_get_option( 'intech_op_header6_btn_border_c' );
            $intech_op_header6_btn_border_hc = cs_get_option( 'intech_op_header6_btn_border_hc' );
            $intech_op_header6_btn_text_c = cs_get_option( 'intech_op_header6_btn_text_c' );
            $intech_op_header6_btn_text_hc = cs_get_option( 'intech_op_header6_btn_text_hc' );
            $intech_op_header6_position = cs_get_option( 'intech_op_header6_position' );
            $intech_op_header6_menu_c = cs_get_option( 'intech_op_header6_menu_c' );
            $intech_op_header6_menu_hc = cs_get_option( 'intech_op_header6_menu_hc' );
            $intech_op_header6_sticky_bg = cs_get_option( 'intech_op_header6_sticky_bg' );
            if(!empty($intech_op_header6_bg)){
                $intech_custom_css_add .= '.header-area.header6{background-color:' . esc_attr( $intech_op_header6_bg ) . '}';
            }
            if(!empty($intech_op_header6_sticky_bg)){
                $intech_custom_css_add .= '.header-area.header6 .header-main-area.on{background-color:' . esc_attr( $intech_op_header6_sticky_bg ) . '}';
            }
            if(!empty($intech_op_header6_btn_bg)){
                $intech_custom_css_add .= '.quote-btn-2{background-color:' . esc_attr( $intech_op_header6_btn_bg ) . '}';
            }
            if(!empty($intech_op_header6_btn_hbg)){
                $intech_custom_css_add .= '.quote-btn-2:hover{background-color:' . esc_attr( $intech_op_header6_btn_hbg ) . '}';
            }
            if(!empty($intech_op_header6_btn_border_c)){
                $intech_custom_css_add .= '.quote-btn-2{border-color:' . esc_attr( $intech_op_header6_btn_border_c ) . '}';
            }
            if(!empty($intech_op_header6_btn_border_hc)){
                $intech_custom_css_add .= '.quote-btn-2:hover{border-color:' . esc_attr( $intech_op_header6_btn_border_hc ) . '}';
            }
            if(!empty($intech_op_header6_btn_text_c)){
                $intech_custom_css_add .= '.quote-btn-2{color:' . esc_attr( $intech_op_header6_btn_text_c ) . '}';
            } 
            if(!empty($intech_op_header6_btn_text_hc)){
                $intech_custom_css_add .= '.quote-btn-2:hover{color:' . esc_attr( $intech_op_header6_btn_text_hc ) . '}';
            }
            if(!empty($intech_op_header6_position)){
                $intech_custom_css_add .= '.header-area.header6{position:' . esc_attr( $intech_op_header6_position ) . '}';
            }
            if(!empty($intech_op_header6_menu_c)){
                $intech_custom_css_add .= '.header-area.header6 #navmenu>ul>li>a{color:' . esc_attr( $intech_op_header6_menu_c ) . '}';
            }
            if(!empty($intech_op_header6_menu_hc)){
                $intech_custom_css_add .= '.header-area.header6 #navmenu>ul>li>a:hover{color:' . esc_attr( $intech_op_header6_menu_hc ) . '}';
            }
        }










        if ( !empty( $intech_copyright_bg ) ) {
            $intech_custom_css_add .= '.footer-copyright-area{background-color:' . esc_attr( $intech_copyright_bg ) . '}';
        }
        if ( !empty( $intech_copyright_text ) ) {
            $intech_custom_css_add .= '.copyright p{color:' . esc_attr( $intech_copyright_text ) . '}';
        }
        if ( !empty( $intech_copyright_link ) ) {
            $intech_custom_css_add .= '.copyright p a{color:' . esc_attr( $intech_copyright_link ) . '}';
        }
        



        if ( $intech_breadcrumb_upload_image_enable == 'true' ) {
            if ( !empty( $intech_breadcrumb_image ) ) {
                $intech_custom_css_add .= '.breadcroumb-boxs{background-image:url(' . esc_url( $intech_breadcrumb_image_array[0] ) . ')}';
            }
            if ( !empty( $intech_breadcrumb_bg_repeat ) ) {
                $intech_custom_css_add .= '.breadcroumb-boxs{background-repeat:' . esc_attr( $intech_breadcrumb_bg_repeat ) . '}';
            }
            if ( !empty( $intech_breadcrumb_bg_position ) ) {
                $intech_custom_css_add .= '.breadcroumb-boxs{background-position:' . esc_attr( $intech_breadcrumb_bg_position ) . '}';
            }
            if ( !empty( $intech_breadcrumb_bg_attach ) ) {
                $intech_custom_css_add .= '.breadcroumb-boxs{background-attachment:' . esc_attr( $intech_breadcrumb_bg_attach ) . '}';
            }
            if ( !empty( $intech_breadcrumb_bg_size ) ) {
                $intech_custom_css_add .= '.breadcroumb-boxs{background-size:' . esc_attr( $intech_breadcrumb_bg_size ) . '}';
            }
            if ( !empty( $intech_breadcrumb_bg_oparicty ) ) {
                $intech_custom_css_add .= '.breadcroumb-boxs:after{background-color:' . esc_attr( $intech_breadcrumb_bg_oparicty ) . '}';
            }
            if ( !empty( $intech_breadcrumb_bg_padding ) ) {
                $intech_custom_css_add .= '.breadcroumb-boxs{padding:' . esc_attr( $intech_breadcrumb_bg_padding ) . '}';
            }
        }
        if ( !empty( $intech_custom_page_padding ) ) {
            $intech_custom_css_add .= '.brea-title h2 {padding:' . esc_attr( $intech_custom_page_padding ) . '}';
        }
        if ( !empty( $intech_page_title_alinement ) ) {
            $intech_custom_css_add .= '.brea-title h2 {text-align:' . esc_attr( $intech_page_title_alinement ) . '}';
        }
        if ( !empty( $intech_custom_page_title_bg ) ) {
            $intech_custom_css_add .= '.brea-title h2 span:after {background-color:' . esc_attr( $intech_custom_page_title_bg ) . '}';
        }
        if ( !empty( $intech_custom_page_title_size ) ) {
            $intech_custom_css_add .= '.brea-title h2 {font-size:' . esc_attr( $intech_custom_page_title_size ) . '}';
        }
        if ( !empty( $intech_custom_page_title_color ) ) {
            $intech_custom_css_add .= '.brea-title h2 {color:' . esc_attr( $intech_custom_page_title_color ) . '}';
        }
        if ( !empty( $intech_page_title_f_width ) ) {
            $intech_custom_css_add .= '.brea-title h2 {font-weight:' . esc_attr( $intech_page_title_f_width ) . '}';
        }
        if ( !empty( $intech_page_title_text_transform ) ) {
            $intech_custom_css_add .= '.brea-title h2 {text-transform:' . esc_attr( $intech_page_title_text_transform ) . '}';
        }

        if($intech_fotter_bg['image']){
            $intech_custom_css_add .= '.footer-top.intech-footer-widgets{background-image:url(' . esc_url( $intech_fotter_bg['image'] ) . ')}';
            $intech_custom_css_add .= '.footer-top.intech-footer-widgets:after{background-color:'.esc_attr($intech_fotter_bg['color'] ).' }';
        }
        if(empty($intech_fotter_bg['image'])){
            $intech_custom_css_add .= '.footer-top.intech-footer-widgets{background-color:'.esc_attr($intech_fotter_bg['color'] ).' }';
        }
        if ( !empty( $intech_fotter_bg['repeat'] ) ) {
            $intech_custom_css_add .= '.footer-top.intech-footer-widgets{background-repeat:' . esc_attr($intech_fotter_bg['repeat'] ) . '}';
        }
        if ( !empty( $intech_fotter_bg['position'] ) ) {
            $intech_custom_css_add .= '.footer-top.intech-footer-widgets{background-position:' . esc_attr( $intech_fotter_bg['position'] ) . '}';
        }
        if ( !empty( $intech_fotter_bg['attachment'] ) ) {
            $intech_custom_css_add .= '.footer-top.intech-footer-widgets{background-attachment:' . esc_attr( $intech_fotter_bg['attachment'] ) . '}';
        }
        if ( !empty( $intech_fotter_bg['size'] ) ) {
            $intech_custom_css_add .= '.footer-top.intech-footer-widgets{background-size:' . esc_attr( $intech_fotter_bg['size'] ) . '}';
        }

        if ( !empty( $intech_theme_color ) ) {
            $intech_custom_css_add .= '
            .tf-info-btn a,button.slick-prev.slick-arrow,button.slick-next.slick-arrow:hover,.slick-dots li.slick-active,.intech-about-v-bg,.pricing-footer a.theme-button:hover,.team-social ul li a:hover,.single-team-social ul li a:hover,.team-social ul li a:hover,.single-team-social ul li a:hover,.support-boxs,a.promoc-btn:hover,.pagination-area ul li a:hover,.pagination-area ul li.active a,.project-menu ul li:hover,.project-menu ul li.active,.project-title a.theme-button:hover,.pro-right a.theme-button:hover,.btn-danger:not(:disabled):not(.disabled).active,.btn-danger:not(:disabled):not(.disabled):active,.show>.btn-danger.dropdown-toggle,.widget.widget_calendar #wp-calendar td#today,.intech-post-protact input[type="submit"],.navigation.pagination ul.page-numbers li>span,.navigation.pagination ul.page-numbers li a:hover,.page-links.post-pagination>ul.page-numbers li a:hover,.page-links.post-pagination>ul.page-numbers li span,.comments-pagination a:hover,.comments-pagination span.page-numbers,.colorbg,.main-menu-btn-icon,
            .main-menu-btn-icon:before,.main-menu-btn-icon:after,.header-area.header4 .theme-logo a,.blog-footer a.theme-button:hover,.to-top,#preloader .square,.widget h2.widget-title:after,h2.widtet-title span:after,h2.widtet-title span:before,form.search-form .search-button button.search-submit,.widget_calendar caption,.intech-cm-btns button[type="submit"]:hover,.tagcloud a:hover,.post-password-required input[type=submit],.about-content>ul li:before,.intech-about-v-bg,ul li>ul .has-submenu.highlighted,.sm-simple ul>li a:hover,ul.sub-menu{background-color:' . esc_attr( $intech_theme_color ) . '}
            .small-title,.pricing-body ul li strong,.intech-theme-buttons.button-style-2 .theme-button,.team-social ul li a,.team-content h2 a:hover,.team-social ul li a,.team-content h2 a:hover,.testimonial-boxs.style-one .testi-content p:after,.testi-content p:after,.testimonial-boxs.style-one .testi-content p:before,.testi-content p:before,span.scolor,.project-video a:hover i:before,.project-hadding span,.project-title a.theme-button i:before,.pro-left h2 a:hover,.service-icon i,.service-titles h3 a:hover,.post-single a:hover,.comment-content a:hover,nav.navigation.post-navigation .nav-links a h3:hover,nav.navigation.post-navigation .nav-links a span,.intech-ftw-box .widget.widget_calendar #wp-calendar td a,.intech-ftw-box .widget_archive ul.sbOptions li a:hover,.intech-ftw-box .widget_categories ul.sbOptions li a:hover,.nave-arcive a:hover,input:focus,button:focus,a:focus,
            .intech-ft-content ul li a:hover,.color1,.header-quote-icon,.header-quote a:hover h4,.header-quote a:hover h2,.blog-top ul li.postby a,.blog-comment-num a:hover,.blog-comment-num a:hover:before,.blog-title h2 a:hover,.intech-post-meta ul li a:hover,h2.post-title a:hover,.intech-cat a,.intech-cat,.footer-menu div>ul>li>a:hover,.bcn_display a,.sticky h2.post-title a,figure a,.blog-list .post-single.format-quote h2.post-title i,.intech-pfg-items .owl-prev:hover,.intech-pfg-items .owl-next:hover,.sidebar .widget ul li a:hover,.widget ul li .comment-author-link a,.widget_rss li a:hover,span.rss-date,.comment-form p.logged-in-as a:hover,.comment-reply a:hover,h3.comment-title>label,h2.post-title>blockquote>a:hover,.about-titles h2 strong,.service-icon i,.service-titles h3 a:hover,.pricing-body ul li strong,ul#main-menu>li>a:hover,ul>li>a.highlighted,ul#main-menu>li>a:hover,.sm-simple ul.sub-menu li a:hover  {color:' . esc_attr( $intech_theme_color ) . '}
            .form-control:focus,.btn-danger:not(:disabled):not(.disabled).active,.btn-danger:not(:disabled):not(.disabled):active,.show>.btn-danger.dropdown-toggle,.intech-post-protact input[type="password"],select:focus,.blog-list .post-single.format-quote,form.search-form input[type="search"]:focus,.intech-comment-filed input:focus,.intech-comment-filed textarea:focus,.wpcf7 form>label>span>input:focus,.wpcf7 form>label>span>textarea:focus,.post-password-required input[type=password]:focus{border-color:' . esc_attr( $intech_theme_color ) . '}
            select:focus,form.search-form input[type="search"]:focus,.intech-comment-filed input:focus, .intech-comment-filed textarea:focus{outline:' . esc_attr( $intech_theme_color ) . '}
            .pricing-icon svg{fill:' . esc_attr( $intech_theme_color ) . '}
            ';
        }
        if ( !empty( $intech_ft_title_color ) ) {
            $intech_custom_css_add .= 'footer h2.widtet-title{color:' . esc_attr( $intech_ft_title_color ) . '}';
        }
        if ( !empty( $intech_ft_title_line_color ) ) {
            $intech_custom_css_add .= 'h2.widtet-title span:before,h2.widtet-title span:after{background-color:' . esc_attr( $intech_ft_title_line_color ) . '}';
        }
        if ( !empty( $intech_ft_icon_color ) ) {
            $intech_custom_css_add .= '.intech-ft-content ul li a:before{color:' . esc_attr( $intech_ft_icon_color ) . '}';
        }
        if ( !empty( $intech_ft_text_color ) ) {
            $intech_custom_css_add .= '.ft-info-dec p, .intech-ft-content p{color:' . esc_attr( $intech_ft_text_color ) . '}';
        }
        if ( !empty( $intech_ft_link_color ) ) {
            $intech_custom_css_add .= '.intech-ft-content ul li a{color:' . esc_attr( $intech_ft_link_color ) . '}';
        }
        if ( !empty( $intech_ft_linkh_color ) ) {
            $intech_custom_css_add .= '.intech-ft-content ul li a:hover{color:' . esc_attr( $intech_ft_linkh_color ) . '}';
        }
        if(!empty($intech_fotter2_bg['image'])){
            $intech_custom_css_add .= '.footer-two{background-image:url(' . esc_url( $intech_fotter2_bg['image'] ) . ')}';
            $intech_custom_css_add .= '.footer-two:after{background-color:'.esc_attr($intech_fotter2_bg['color'] ).' }';
        }
        if(empty($intech_fotter2_bg['image'])){
            $intech_custom_css_add .= '.footer-two{background-color:'.esc_attr($intech_fotter2_bg['color'] ).' }';
        }
        if ( !empty( $intech_fotter2_bg['repeat'] ) ) {
            $intech_custom_css_add .= '.footer-two{background-repeat:' . esc_attr($intech_fotter2_bg['repeat'] ) . '}';
        }
        if ( !empty( $intech_fotter2_bg['position'] ) ) {
            $intech_custom_css_add .= '.footer-two{background-position:' . esc_attr( $intech_fotter2_bg['position'] ) . '}';
        }
        if ( !empty( $intech_fotter2_bg['attachment'] ) ) {
            $intech_custom_css_add .= '.footer-two{background-attachment:' . esc_attr( $intech_fotter2_bg['attachment'] ) . '}';
        }
        if ( !empty( $intech_fotter2_bg['size'] ) ) {
            $intech_custom_css_add .= '.footer-two{background-size:' . esc_attr( $intech_fotter2_bg['size'] ) . '}';
        }
        if ( !empty( $intech_fotter2_animation_bg ) ) {
            $intech_custom_css_add .= '.ftcircles li{background:' . esc_attr( $intech_fotter2_animation_bg ) . '}';
        }
        $intech_fotter3_top_bg = cs_get_option( 'intech_fotter3_top_bg' );
        $intech_fotter3_iconbg = cs_get_option( 'intech_fotter3_iconbg' );
        $intech_fotter3_ico = cs_get_option( 'intech_fotter3_ico' );
        $intech_fotter3_label = cs_get_option( 'intech_fotter3_label' );
        $intech_fotter3_link_c = cs_get_option( 'intech_fotter3_link_c' );
        $intech_fotter3_link_hc = cs_get_option( 'intech_fotter3_link_hc' );
        $intech_fotter3_bg = cs_get_option( 'intech_fotter3_bg' );
        $intech_fotter3_copyright_text = cs_get_option( 'intech_fotter3_copyright_text' );
        $intech_fotter3_copyright = cs_get_option( 'intech_fotter3_copyright' );
        if ( !empty( $intech_fotter3_top_bg ) ) {
            $intech_custom_css_add .= '.ft3-top>.container{background-image:url(' . esc_url( $intech_fotter3_top_bg ) . ')}';
        }
        if ( !empty( $intech_fotter3_iconbg ) ) {
            $intech_custom_css_add .= '.ft3-icon i{background:' . esc_attr( $intech_fotter3_iconbg ) . '}';
        }
        if ( !empty( $intech_fotter3_ico ) ) {
            $intech_custom_css_add .= '.ft3-icon i{color:' . esc_attr( $intech_fotter3_ico ) . '}';
        }
        if ( !empty( $intech_fotter3_label ) ) {
            $intech_custom_css_add .= '.ft3-content label{color:' . esc_attr( $intech_fotter3_label ) . '}';
        }
        if ( !empty( $intech_fotter3_link_c ) ) {
            $intech_custom_css_add .= '.ft3-content a, .ft3-content span{color:' . esc_attr( $intech_fotter3_link_c ) . '}';
        }
        if ( !empty( $intech_fotter3_link_hc ) ) {
            $intech_custom_css_add .= '.ft3-content a:hover span{color:' . esc_attr( $intech_fotter3_link_hc ) . '}';
        }


        if(!empty($intech_fotter3_bg['image'])){
            $intech_custom_css_add .= '.footer-three .footer-top.intech-footer-widgets{background-image:url(' . esc_url( $intech_fotter3_bg['image'] ) . ')}';
            if(!empty($intech_fotter3_bg['image'])){
                $intech_custom_css_add .= '.footer-three .footer-top.intech-footer-widgets:after{background-color:'.esc_attr($intech_fotter3_bg['color'] ).' }';
            }
            if ( !empty( $intech_fotter3_bg['repeat'] ) ) {
                $intech_custom_css_add .= '.footer-three .footer-top.intech-footer-widgets{background-repeat:' . esc_attr($intech_fotter3_bg['repeat'] ) . '}';
            }
            if ( !empty( $intech_fotter3_bg['position'] ) ) {
                $intech_custom_css_add .= '.footer-three .footer-top.intech-footer-widgets{background-position:' . esc_attr( $intech_fotter3_bg['position'] ) . '}';
            }
            if ( !empty( $intech_fotter3_bg['attachment'] ) ) {
                $intech_custom_css_add .= '.footer-three .footer-top.intech-footer-widgets{background-attachment:' . esc_attr( $intech_fotter3_bg['attachment'] ) . '}';
            }
            if ( !empty( $intech_fotter3_bg['size'] ) ) {
                $intech_custom_css_add .= '.footer-three .footer-top.intech-footer-widgets{background-size:' . esc_attr( $intech_fotter3_bg['size'] ) . '}';
            }
        }
        if(empty($intech_fotter3_bg['image'])){
            $intech_custom_css_add .= '.footer-three .footer-top.intech-footer-widgets{background-color:'.esc_attr($intech_fotter3_bg['color'] ).' }';
        }
        if(!empty($intech_fotter3_copyright)){
            $intech_custom_css_add .= '.footer-three .footer-copyright-area{background-color:'.esc_attr($intech_fotter3_copyright ).' }';
        }
        if(!empty($intech_fotter3_copyright_text)){
            $intech_custom_css_add .= '.footer-three .copyright p{color:'.esc_attr($intech_fotter3_copyright_text ).' }';
        }
        wp_add_inline_style( 'intech-custom-style', $intech_custom_css_add );
    }
}
add_action( 'wp_enqueue_scripts', 'intech_custom_css' );