<?php
class intech_Recent_Posts_Widget extends WP_Widget {
// Main constructor
	public function __construct() {

		$widget_id       = 'intech_recent_post';
		$widget_title    = esc_html__( 'intech Recent Post With Thumbnails', 'intechcore' );
		$widget_settings = array(
			'customize_selective_refresh' => true,
			'classname'                   => 'intech_Recent_Posts_Widget',
			'description'                 => esc_html__( 'Display Recent Posts with thumbnails', 'intechcore' )
		);

		parent::__construct( $widget_id, $widget_title, $widget_settings );
	}
// The widget form (for the backend )
	public function form( $instance ) {
// Set widget defaults
		$defaults = array(
			'title' => esc_html__( 'Recent Posts', 'intechcore' ),
			'intech_count' => 3,
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<!-- Title -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Widget Title', 'intechcore' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>"/>
		</p>
		<!-- Posts intech_count -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'intech_count' ) ); ?>"><?php esc_html_e( 'Posts Count:', 'intechcore' ); ?></label>
			<input type="number" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'intech_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'intech_count' ) ); ?>" value="<?php echo esc_attr( $instance['intech_count'] ); ?>"/>
		</p>
		<?php
	}
// Update widget settings
	public function update( $new_instance, $old_instance ) {
		$instance          = $old_instance;
		$instance['title'] = isset( $new_instance['title'] ) ? wp_strip_all_tags( $new_instance['title'] ) : '';
		$instance['intech_count'] = isset( $new_instance['intech_count'] ) ? wp_strip_all_tags( $new_instance['intech_count'] ) : '';
		return $instance;
	}
// Display the widget
	public function widget( $args, $instance ) {
		extract( $args );
		// Check the widget options
		$title = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : esc_html_e('Instagram Feed','intechcore');
		$intech_count = isset( $instance['intech_count'] ) ? $instance['intech_count'] : 3 ;
		echo wp_kses_post($before_widget);
		if ( ! empty($title) ) :
			echo wp_kses_post( $before_title ) . esc_html( $title ) . wp_kses_post( $after_title );
		endif; ?>
		<div class="widget-recent-posts">
			<?php
			$intech_sticky = get_option( 'sticky_posts' );
			$intech_query   = new WP_Query( array(
				'posts_per_page'      => $intech_count,
				'ignore_sticky_posts' => 1,
				'post__not_in'        => $intech_sticky,
			) );
			?>
			<?php if ( $intech_query ->have_posts() ) : while ( $intech_query ->have_posts() ) : $intech_query ->the_post(); ?>
				<div class="intech-recent-post-single">
					<?php if ( has_post_thumbnail() ) { ?>
					<div class="intech-widget-recent-post-img">
						<a href="<?php esc_url(the_permalink()); ?>"><img src="<?php esc_url(the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>" class="widget-posts-img"></a>
					</div>
					<?php } ?>
					<div class="intech-widget-posts-descr">
						<h3 class="intech-widget-post-title post-title">
						<a href="<?php esc_url( the_permalink() ); ?>" class="title"><?php echo esc_html( get_the_title(), 6 ); ?></a>
						</h3>
						<div class="date"><?php echo esc_html( get_the_date() ); ?></div>
					</div>
				</div>
			<?php endwhile; endif; ?>
		</div>
		<?php echo wp_kses_post($after_widget);
	}
}
// Register Widget
function intech_register_recent_posts_widget() {
	register_widget( 'intech_Recent_Posts_Widget' );
}
add_action( 'widgets_init', 'intech_register_recent_posts_widget' );