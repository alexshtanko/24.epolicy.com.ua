<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor progress widget.
 *
 * Elementor widget that displays an escalating progress bar.
 *
 * @since 1.0.0
 */
class intech_coninfo_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve progress widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'intech-contact-info';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve progress widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'intech contact Info', 'intechcore' );
	}

    
	public function get_categories() {
		return [ 'intechcore' ];
	}
    
	/**
	 * Get widget icon.
	 *
	 * Retrieve progress widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-t-letter';
	}
	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'intech', 'Contact info' ];
	}

	/**
	 * Register progress widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'intech_coninfo_section',
			[
				'label' => esc_html__( 'Content', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'intech_coninfo_title',
			[
			    'label' => esc_html__( 'Title', 'intechcore' ),
			    'type'          => Controls_Manager::TEXT,
			    'default'       => esc_html__('Contact Info','intechcore'),
			]
		);
		$this->add_control(
			'intech_coninfo_hcontent',
			[
			    'label' => esc_html__( 'Content', 'intechcore' ),
			    'type' => Controls_Manager::TEXTAREA,
			    'default' => esc_html__( 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.','intechcore' )
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'intech_coninfo_list_contnet',
			[
			    'label' => esc_html__( 'Content', 'intechcore' ),
			    'type'          => Controls_Manager::TEXTAREA,
			    'default'       => esc_html__('Dambo Dika US. Road 123','intechcore'),
			]
		);
		$repeater->add_control(
			'intech_coninfo_icon',
			[
			'label' => esc_html__( 'Icon', 'intechcore' ),
			'type' => Controls_Manager::ICON,
			'label_block' => true,
			'default' => 'flaticon-pin',
			]
		);
		$this->add_control(
			'intech_coninfo_slides',
				[
				'label' => esc_html__( 'Repeater List', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'intech_coninfo_list_contnet' => esc_html__( 'Dambo Dika US. Road 123', 'intechcore' ),
						'intech_coninfo_icon' => 'flaticon-pin',
					],
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
            'restly_contact_info_CSS_box',
            [
                'label' => esc_html__( 'Box', 'restlycore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'restly_contact_info_CSS_box_aling',
			[
				'label' => __( 'Alignment', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'restlycore' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'restlycore' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'restlycore' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .coninfo-boxs' => 'text-align: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'restly_contact_info_CSS_box_background',
				'label' => esc_html__( 'Background', 'restlycore' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .coninfo-boxs',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'restly_contact_info_CSS_box_border',
				'label' => esc_html__( 'Border', 'restlycore' ),
				'selector' => '{{WRAPPER}} .coninfo-boxs',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'restly_contact_info_CSS_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'restlycore' ),
				'selector' => '{{WRAPPER}} .coninfo-boxs',
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_box_margin',
			[
				'label' => esc_html__( 'Margin', 'restlycore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .coninfo-boxs' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_box_padding',
			[
				'label' => esc_html__( 'Padding', 'restlycore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .coninfo-boxs' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
            'restly_contact_info_CSS_content',
            [
                'label' => esc_html__( 'Content', 'restlycore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->start_controls_tabs(
			'restly_contact_info_CSS_tabs'
		);
		$this->start_controls_tab(
			'restly_contact_info_CSS_tabs_title',
			[
				'label' => __( 'Title', 'restlycore' ),
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_title_color',
			[
				'label' => esc_html__( 'Title Color', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .coninfo-title h2' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'restly_contact_info_CSS_tabs_title_typography',
				'label' => esc_html__( 'Typography', 'restlycore' ),
				'selector' => '{{WRAPPER}} .coninfo-title h2',
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_title_margin',
			[
				'label' => esc_html__( 'Margin', 'restlycore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .coninfo-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_title_padding',
			[
				'label' => esc_html__( 'Padding', 'restlycore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .coninfo-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'restly_restly_contact_info_CSS_tabs_text',
			[
				'label' => __( 'Text', 'restlycore' ),
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_text_color',
			[
				'label' => esc_html__( 'Color', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .coninfo-dec' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'restly_contact_info_CSS_tabs_text_typography',
				'label' => esc_html__( 'Typography', 'restlycore' ),
				'selector' => '{{WRAPPER}} .coninfo-dec',
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_text_margin',
			[
				'label' => esc_html__( 'Margin', 'restlycore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .coninfo-dec' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_ttex_padding',
			[
				'label' => esc_html__( 'Padding', 'restlycore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .coninfo-dec' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'restly_restly_contact_info_CSS_tabs_list',
			[
				'label' => __( 'Item List', 'restlycore' ),
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_list_color',
			[
				'label' => esc_html__( 'Color', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .contact-info-list ul li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'restly_contact_info_CSS_tabs_list_typography',
				'label' => esc_html__( 'Typography', 'restlycore' ),
				'selector' => '{{WRAPPER}} .contact-info-list ul li',
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_list_margin',
			[
				'label' => esc_html__( 'Margin', 'restlycore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .contact-info-list ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'restly_contact_info_CSS_tabs_list_padding',
			[
				'label' => esc_html__( 'Padding', 'restlycore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .contact-info-list ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Render progress widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		?>
		<div class="coninfo-boxs">
			<div class="coninfo-title">
				<h2><?php echo esc_html($settings['intech_coninfo_title']) ?></h2>
			</div>
			<div class="coninfo-dec">
				<?php echo esc_html($settings['intech_coninfo_hcontent']); ?>
			</div>
			<div class="contact-info-list">
				<ul>
				 <?php foreach ($settings['intech_coninfo_slides'] as $intech_coninfo_slide) : ?>
					<li><i class="<?php echo esc_attr($intech_coninfo_slide['intech_coninfo_icon']); ?>"></i> <label><?php echo esc_html($intech_coninfo_slide['intech_coninfo_list_contnet']); ?></label></li>
				 <?php endforeach; ?>
				</ul>
			</div>
		</div>
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_coninfo_Widget );