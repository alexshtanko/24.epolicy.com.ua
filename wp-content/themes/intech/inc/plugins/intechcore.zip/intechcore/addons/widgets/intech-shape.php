<?php
namespace Elementor;

class intech_Animation_shape_Widget extends Widget_Base {

    public function get_name() {

        return 'intech_Animation_shape';
    }

    public function get_title() {
        return esc_html__( 'intech Shape Animation', 'intechcore' );
    }

    public function get_icon() {

        return 'eicon-handle';
    }

    public function get_categories() {
        return ['intechcore'];
    }

    protected function _register_controls() {

        //Content tab start
        $this->start_controls_section(
            'intech_Animation_shape_options',
            [
                'label' => esc_html__( 'intech Animation Shape 1', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'intech_shape1_enable',
            [
                'label' => esc_html__( 'Enable Shape', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'intechcore' ),
                'label_off' => esc_html__( 'Hide', 'intechcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'intech_shape_select',
            [
                'label'   => esc_html__( 'Select Animation', 'intechcore' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'shapeMover',
                'options'   => [
                    'shapeMover'        => esc_html__( 'Shape Mover', 'intechcore' ),
                    'bubbleMover'       => esc_html__( 'Bubble Mover', 'intechcore' ),
                    'bounce'            => esc_html__( 'Bounce', 'intechcore' ),
                    'zoomIn'            => esc_html__( 'ZoomIn', 'intechcore' ),
                    'flash'             => esc_html__( 'Flash', 'intechcore' ),
                    'pulse'             => esc_html__( 'Pulse', 'intechcore' ),
                    'rubberBand'        => esc_html__( 'Rubber Band', 'intechcore' ),
                    'shake'             => esc_html__( 'ShakeX', 'intechcore' ),
                    'fadeIn'            => esc_html__( 'FadeIn', 'intechcore' ),
                    'fadeInDown'        => esc_html__( 'FadeIn Down', 'intechcore' ),
                    'fadeInLeft'        => esc_html__( 'FadeIn Left', 'intechcore' ),
                    'fadeInRight'       => esc_html__( 'FadeIn Right', 'intechcore' ),
                    'fadeInUp'          => esc_html__( 'FadeIn Up', 'intechcore' ),
                    'fadeOut'           => esc_html__( 'FadeOut', 'intechcore' ),
                    'fadeOutDown'       => esc_html__( 'FadeOut Down', 'intechcore' ),
                    'fadeOutLeft'       => esc_html__( 'FadeOut Left', 'intechcore' ),
                    'fadeOutRight'      => esc_html__( 'FadeOut Right', 'intechcore' ),
                    'fadeOutUp'         => esc_html__( 'FadeOut Up', 'intechcore' ),
                    'flip'              => esc_html__( 'Flip', 'intechcore' ),
                    'flipInX'           => esc_html__( 'FlipInX', 'intechcore' ),
                    'flipInY'           => esc_html__( 'FlipInY', 'intechcore' ),
                    'rotateIn'          => esc_html__( 'RotateIn', 'intechcore' ),
                    'rotateInDownLeft'  => esc_html__( 'RotateIn Down Left', 'intechcore' ),
                    'rotateInDownRight' => esc_html__( 'RotateIn Down Right', 'intechcore' ),
                    'rotateInUpLeft'    => esc_html__( 'RotateIn Up Left', 'intechcore' ),
                    'rotateInUpRight'   => esc_html__( 'RotateIn Up Right', 'intechcore' ),
                    'rotateOut'         => esc_html__( 'Rotate Out', 'intechcore' ),
                    'hinge'             => esc_html__( 'Hinge', 'intechcore' ),
                    'slideInDown'       => esc_html__( 'SlideIn Down', 'intechcore' ),
                    'slideInLeft'       => esc_html__( 'SlideIn Left', 'intechcore' ),
                    'slideInRight'      => esc_html__( 'SlideIn Right', 'intechcore' ),
                ],
                'condition' => [
                    'intech_shape1_enable' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'intech_shape_img',
            [
                'label'   => __( 'Choose Image', 'intechcore' ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'intech_shape1_enable' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'intech_Animation_shape2_options',
            [
                'label' => esc_html__( 'intech Animation Shape 2', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                
            ]
        );
        $this->add_control(
            'intech_shape2_enable',
            [
                'label' => esc_html__( 'Enable Shape', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'intechcore' ),
                'label_off' => esc_html__( 'Hide', 'intechcore' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_control(
            'intech_shape2_select',
            [
                'label'   => esc_html__( 'Select Animation', 'intechcore' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'shapeMover',
                'options'   => [
                    'shapeMover'        => esc_html__( 'Shape Mover', 'intechcore' ),
                    'bubbleMover'       => esc_html__( 'Bubble Mover', 'intechcore' ),
                    'bounce'            => esc_html__( 'Bounce', 'intechcore' ),
                    'zoomIn'            => esc_html__( 'ZoomIn', 'intechcore' ),
                    'flash'             => esc_html__( 'Flash', 'intechcore' ),
                    'pulse'             => esc_html__( 'Pulse', 'intechcore' ),
                    'rubberBand'        => esc_html__( 'Rubber Band', 'intechcore' ),
                    'shake'             => esc_html__( 'ShakeX', 'intechcore' ),
                    'fadeIn'            => esc_html__( 'FadeIn', 'intechcore' ),
                    'fadeInDown'        => esc_html__( 'FadeIn Down', 'intechcore' ),
                    'fadeInLeft'        => esc_html__( 'FadeIn Left', 'intechcore' ),
                    'fadeInRight'       => esc_html__( 'FadeIn Right', 'intechcore' ),
                    'fadeInUp'          => esc_html__( 'FadeIn Up', 'intechcore' ),
                    'fadeOut'           => esc_html__( 'FadeOut', 'intechcore' ),
                    'fadeOutDown'       => esc_html__( 'FadeOut Down', 'intechcore' ),
                    'fadeOutLeft'       => esc_html__( 'FadeOut Left', 'intechcore' ),
                    'fadeOutRight'      => esc_html__( 'FadeOut Right', 'intechcore' ),
                    'fadeOutUp'         => esc_html__( 'FadeOut Up', 'intechcore' ),
                    'flip'              => esc_html__( 'Flip', 'intechcore' ),
                    'flipInX'           => esc_html__( 'FlipInX', 'intechcore' ),
                    'flipInY'           => esc_html__( 'FlipInY', 'intechcore' ),
                    'rotateIn'          => esc_html__( 'RotateIn', 'intechcore' ),
                    'rotateInDownLeft'  => esc_html__( 'RotateIn Down Left', 'intechcore' ),
                    'rotateInDownRight' => esc_html__( 'RotateIn Down Right', 'intechcore' ),
                    'rotateInUpLeft'    => esc_html__( 'RotateIn Up Left', 'intechcore' ),
                    'rotateInUpRight'   => esc_html__( 'RotateIn Up Right', 'intechcore' ),
                    'rotateOut'         => esc_html__( 'Rotate Out', 'intechcore' ),
                    'hinge'             => esc_html__( 'Hinge', 'intechcore' ),
                    'slideInDown'       => esc_html__( 'SlideIn Down', 'intechcore' ),
                    'slideInLeft'       => esc_html__( 'SlideIn Left', 'intechcore' ),
                    'slideInRight'      => esc_html__( 'SlideIn Right', 'intechcore' ),
                ],
                'condition' => [
                    'intech_shape2_enable' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'intech_shape_img2',
            [
                'label'   => __( 'Choose Image', 'intechcore' ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'intech_shape2_enable' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'intech_Animation_shape3_options',
            [
                'label' => esc_html__( 'intech Animation Shape 3', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                
            ]
        );
        $this->add_control(
            'intech_shape3_enable',
            [
                'label' => esc_html__( 'Enable Shape', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'intechcore' ),
                'label_off' => esc_html__( 'Hide', 'intechcore' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_control(
            'intech_shape3_select',
            [
                'label'   => esc_html__( 'Select Animation', 'intechcore' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'shapeMover',
                'options'   => [
                    'shapeMover'        => esc_html__( 'Shape Mover', 'intechcore' ),
                    'bubbleMover'       => esc_html__( 'Bubble Mover', 'intechcore' ),
                    'bounce'            => esc_html__( 'Bounce', 'intechcore' ),
                    'zoomIn'            => esc_html__( 'ZoomIn', 'intechcore' ),
                    'flash'             => esc_html__( 'Flash', 'intechcore' ),
                    'pulse'             => esc_html__( 'Pulse', 'intechcore' ),
                    'rubberBand'        => esc_html__( 'Rubber Band', 'intechcore' ),
                    'shake'             => esc_html__( 'ShakeX', 'intechcore' ),
                    'fadeIn'            => esc_html__( 'FadeIn', 'intechcore' ),
                    'fadeInDown'        => esc_html__( 'FadeIn Down', 'intechcore' ),
                    'fadeInLeft'        => esc_html__( 'FadeIn Left', 'intechcore' ),
                    'fadeInRight'       => esc_html__( 'FadeIn Right', 'intechcore' ),
                    'fadeInUp'          => esc_html__( 'FadeIn Up', 'intechcore' ),
                    'fadeOut'           => esc_html__( 'FadeOut', 'intechcore' ),
                    'fadeOutDown'       => esc_html__( 'FadeOut Down', 'intechcore' ),
                    'fadeOutLeft'       => esc_html__( 'FadeOut Left', 'intechcore' ),
                    'fadeOutRight'      => esc_html__( 'FadeOut Right', 'intechcore' ),
                    'fadeOutUp'         => esc_html__( 'FadeOut Up', 'intechcore' ),
                    'flip'              => esc_html__( 'Flip', 'intechcore' ),
                    'flipInX'           => esc_html__( 'FlipInX', 'intechcore' ),
                    'flipInY'           => esc_html__( 'FlipInY', 'intechcore' ),
                    'rotateIn'          => esc_html__( 'RotateIn', 'intechcore' ),
                    'rotateInDownLeft'  => esc_html__( 'RotateIn Down Left', 'intechcore' ),
                    'rotateInDownRight' => esc_html__( 'RotateIn Down Right', 'intechcore' ),
                    'rotateInUpLeft'    => esc_html__( 'RotateIn Up Left', 'intechcore' ),
                    'rotateInUpRight'   => esc_html__( 'RotateIn Up Right', 'intechcore' ),
                    'rotateOut'         => esc_html__( 'Rotate Out', 'intechcore' ),
                    'hinge'             => esc_html__( 'Hinge', 'intechcore' ),
                    'slideInDown'       => esc_html__( 'SlideIn Down', 'intechcore' ),
                    'slideInLeft'       => esc_html__( 'SlideIn Left', 'intechcore' ),
                    'slideInRight'      => esc_html__( 'SlideIn Right', 'intechcore' ),
                ],
                'condition' => [
                    'intech_shape3_enable' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'intech_shape_img3',
            [
                'label'   => __( 'Choose Image', 'intechcore' ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'intech_shape3_enable' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();


        $this->start_controls_section(
            'intech_Animation_shape_css_options',
            [
                'label' => esc_html__( 'CSS Shape 1', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'intech_shape1_enable' => 'yes',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape_top',
            [
                'label' => esc_html__( 'Top To Bottom', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .shapeanimation' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape_left',
            [
                'label' => esc_html__( 'Left To Right', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .shapeanimation' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape_duration',
            [
                'label' => esc_html__( 'Animation Duration', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 's' ],
                'range' => [
                    's' => [
                        'min' => 0.1,
                        'max' => 100,
                        'step' => 0.1,
                    ]
                ],
                'default' => [
                    'unit' => 's',
                    'size' => 9,
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'intech_Animation_shape2_css_options',
            [
                'label' => esc_html__( 'CSS Shape 2', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'intech_shape2_enable' => 'yes',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape2_top',
            [
                'label' => esc_html__( 'Top To Bottom', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .shapeanimation.shape2' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape2_left',
            [
                'label' => esc_html__( 'Left To Right', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .shapeanimation.shape2' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape2_duration',
            [
                'label' => esc_html__( 'Animation Duration', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 's' ],
                'range' => [
                    's' => [
                        'min' => 0.1,
                        'max' => 100,
                        'step' => 0.1,
                    ]
                ],
                'default' => [
                    'unit' => 's',
                    'size' => 9,
                ],
            ]
        );
        $this->end_controls_section();


        $this->start_controls_section(
            'intech_Animation_shape3_css_options',
            [
                'label' => esc_html__( 'CSS Shape 3', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'intech_shape3_enable' => 'yes',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape3_top',
            [
                'label' => esc_html__( 'Top To Bottom', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .shapeanimation.shape3' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape3_left',
            [
                'label' => esc_html__( 'Left To Right', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 2000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .shapeanimation.shape3' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_shape3_duration',
            [
                'label' => esc_html__( 'Animation Duration', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 's' ],
                'range' => [
                    's' => [
                        'min' => 0.1,
                        'max' => 100,
                        'step' => 0.1,
                    ]
                ],
                'default' => [
                    'unit' => 's',
                    'size' => 9,
                ],
            ]
        );
        $this->end_controls_section();
    }
    //Render
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <?php 
        ob_start();
        if($settings['intech_shape1_enable'] == 'yes'){
            echo '<img src="'.esc_url($settings['intech_shape_img']['url']).'" alt="'.esc_attr('intech Shape','intechcore').'" class="bubbleMover shapeanimation" style="-webkit-animation-name:'.esc_attr($settings['intech_shape_select']).';
            animation-name: '.esc_attr($settings['intech_shape_select']).'; animation-duration:'.esc_attr($settings['intech_shape_duration']['size']).'s;-webkit-animation-duration:'.esc_attr($settings['intech_shape_duration']['size']).'s">';
        }
        if($settings['intech_shape2_enable'] == 'yes'){
            echo '<img src="'.esc_url($settings['intech_shape_img2']['url']).'" alt="'.esc_attr('intech Shape','intechcore').'" class="bubbleMover shapeanimation shape2" style="-webkit-animation-name:'.esc_attr($settings['intech_shape2_select']).';
            animation-name: '.esc_attr($settings['intech_shape2_select']).'; animation-duration:'.esc_attr($settings['intech_shape2_duration']['size']).'s;-webkit-animation-duration:'.esc_attr($settings['intech_shape2_duration']['size']).'s">';
        }
        if($settings['intech_shape3_enable'] == 'yes'){
            echo '<img src="'.esc_url($settings['intech_shape_img3']['url']).'" alt="'.esc_attr('intech Shape','intechcore').'" class="bubbleMover shapeanimation shape3" style="-webkit-animation-name:'.esc_attr($settings['intech_shape3_select']).';
            animation-name: '.esc_attr($settings['intech_shape3_select']).'; animation-duration:'.esc_attr($settings['intech_shape3_duration']['size']).'s;-webkit-animation-duration:'.esc_attr($settings['intech_shape3_duration']['size']).'s">';
        }
       
        echo ob_get_clean();
    }
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_Animation_shape_Widget );