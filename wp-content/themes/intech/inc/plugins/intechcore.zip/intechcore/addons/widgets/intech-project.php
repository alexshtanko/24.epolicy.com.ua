<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor progress widget.
 *
 * Elementor widget that displays an escalating progress bar.
 *
 * @since 1.0.0
 */
class intech_project_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve progress widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'intech-project';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve progress widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'intech Project', 'intechcore' );
	}


	public function get_categories() {
		return [ 'intechcore' ];
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve progress widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-t-letter';
	}
	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'intech', 'project' ];
	}

	/**
	 * Register progress widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'intech_projects_contnet',
			[
				'label' => esc_html__( 'Content', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'intech_project_stitle',
			[
			    'label' => esc_html__( 'Small Title', 'intechcore' ),
			    'type'          => Controls_Manager::TEXT,
			    'default'       => esc_html__('Latest Project','intechcore'),
			]
		);
		$this->add_control(
			'intech_project_hadding',
			[
			    'label' => esc_html__( 'Hadding', 'intechcore' ),
			    'type' => Controls_Manager::TEXTAREA,
			    'default' => esc_html__( 'There are more latest project done yet.','intechcore' ),
			    'placeholder' => esc_html__( 'Hadding', 'intechcore' ),
			]
		);
		$this->add_control(
			'intech_project_style',
			[
				'label' => esc_html__( 'Select Style', 'intechcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1'  => esc_html__( 'Style One', 'intechcore' ),
					'2'  => esc_html__( 'Style Two', 'intechcore' ),
					'3'  => esc_html__( 'Style Three', 'intechcore' ),
				],
			]
		);
		$this->add_control(
			'intech_project_enable_sliders',
			[
				'label' => esc_html__( 'Enable Slide ?', 'intechcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'intechcore' ),
				'label_off' => esc_html__( 'Hide', 'intechcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'intech_project_style' => '1',
				]
			]
		);
		
		$this->add_control(
			'intech_project_nav',
			[
				'label' => esc_html__( 'Enable Nav', 'intechcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'intechcore' ),
				'label_off' => esc_html__( 'Hide', 'intechcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'intech_project_style' => '1',
					'intech_project_enable_sliders' => 'yes',
				]
			]
		);
		$this->add_control(
			'intech_project_aplay',
			[
				'label' => esc_html__( 'Enable Auto Play', 'intechcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'intechcore' ),
				'label_off' => esc_html__( 'Hide', 'intechcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'intech_project_style' => '1',
					'intech_project_enable_sliders' => 'yes',
				]
			]
		);
		$this->add_control(
			'intech_project_aspeed_enable',
			[
				'label' => esc_html__( 'Enable Auto Play Speed', 'intechcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'intechcore' ),
				'label_off' => esc_html__( 'Hide', 'intechcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'intech_project_style' => '1',
					'intech_project_enable_sliders' => 'yes',
				]
			]
		);
		$this->add_control(
			'intech_project_aspeed',
			[
				'label' 	=> esc_html__( 'Slide auto Speed', 'intechcore' ),
			    	'type' 	=> Controls_Manager::NUMBER,
			    	'min' 	=> 500,
			    	'max' 	=> 5000,
			    	'step' 	=> 50,
			    	'default' 	=> 1500,
			   	'condition' => array(
					'intech_project_style' => '1',
					'intech_project_aspeed_enable' => 'yes',
					'intech_project_enable_sliders' => 'yes',

				)
			]
		);
		$this->add_control(
			'intech_project_speed_enable',
			[
				'label' => esc_html__( 'Enable Speed', 'intechcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'intechcore' ),
				'label_off' => esc_html__( 'Hide', 'intechcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'intech_project_style' => '1',
					'intech_project_enable_sliders' => 'yes',
				]
			]
		);
		$this->add_control(
			'intech_project_speed',
			[
				'label' 	=> esc_html__( 'Slide Speed', 'intechcore' ),
			    	'type' 	=> Controls_Manager::NUMBER,
			    	'min' 	=> 500,
			    	'max' 	=> 5000,
			    	'step' 	=> 50,
			    	'default' 	=> 1500,
			   	'condition' => array(
					'intech_project_style' => '1',
					'intech_project_speed_enable' => 'yes',
					'intech_project_enable_sliders' => 'yes',

				)
			]
		);
		$this->add_responsive_control(
			'intech_project_vicon_position',
			[
			    'label' => esc_html__( 'video Icon position', 'intechcore' ),
			    'type' => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range' => [
				  'px' => [
					'min' => -200,
					'max' => 200,
					'step' => 1,
				  ],
				  '%' => [
					'min' => -100,
					'max' => 100,
				  ],
			    ],
			    'selectors' => [
				  '{{WRAPPER}} .project-video' => 'top: {{SIZE}}{{UNIT}};'
			    ],
			]
		);
		$this->add_responsive_control(
			'intech_project_button_position',
			[
			    'label' => esc_html__( 'button Position Bottom', 'intechcore' ),
			    'type' => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range' => [
				  'px' => [
					'min' => -100,
					'max' => 500,
					'step' => 1,
				  ],
				  '%' => [
					'min' => -100,
					'max' => 100,
				  ],
			    ],
			    'selectors' => [
				  '{{WRAPPER}} .project-box .project-title' => 'bottom: {{SIZE}}{{UNIT}};'
			    ],
			]
		);
		$this->add_responsive_control(
			'intech_project_button_position_r',
			[
			    'label' => esc_html__( 'button Position Right', 'intechcore' ),
			    'type' => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range' => [
				  'px' => [
					'min' => -100,
					'max' => 500,
					'step' => 1,
				  ],
				  '%' => [
					'min' => -100,
					'max' => 100,
				  ],
			    ],
			    'selectors' => [
				  '{{WRAPPER}} .project-box .project-title' => 'right: {{SIZE}}{{UNIT}};'
			    ],
			]
		);
		$this->add_control(
			'intech_project_per_post',
			[
			    'label' => esc_html__( 'Show Items', 'intechcore' ),
			   'type' 	=> Controls_Manager::NUMBER,
			    	'min' 	=> -1,
			    	'max' 	=> 15,
			    	'step' 	=> 1,
			    	'default' 	=> -1,
			]
		);
		$this->add_control(
			'intech_project_pagi',
			[
				'label' => esc_html__( 'Enable Pagination', 'intechcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'intechcore' ),
				'label_off' => esc_html__( 'Hide', 'intechcore' ),
				'return_value' => 'yes',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'intech_project_hadding_style',
			[
				'label' => esc_html__( 'Hadding', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'intech_project_hsaline',
			[
			'label' => esc_html__( 'Alignment', 'intechcore' ),
			'type' => Controls_Manager::CHOOSE,
			'options' => [
				'left' => [
					'title' => esc_html__( 'Left', 'intechcore' ),
					'icon' => 'fa fa-align-left',
				],
				'center' => [
					'title' => esc_html__( 'Center', 'intechcore' ),
					'icon' => 'fa fa-align-center',
				],
				'right' => [
					'title' => esc_html__( 'Right', 'intechcore' ),
					'icon' => 'fa fa-align-right',
				],
				'justify' => [
					'title' => esc_html__( 'Justified', 'intechcore' ),
					'icon' => 'fa fa-align-justify',
				],
			],
			'selectors' => [
				'{{WRAPPER}} .project-hadding' => 'text-align: {{VALUE}};',
			],
			'default' => 'left',
			'separator' =>'before',
			]
		);
		$this->add_control(
			'intech_project_hscolor',
			[
				'label' => esc_html__( 'Small Text Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#0b5be0',
				'selectors' => [
					'{{WRAPPER}} .project-hadding span' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
			    'name' => 'intech_project_stypo',
			    'label' => esc_html__( 'Small Text Typography', 'intechcore' ),
			    'selector' => '{{WRAPPER}} .project-hadding span',
			]
		);
		$this->add_control(
			'intech_project_hcolor',
			[
				'label' => esc_html__( 'Hadding Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .project-hadding h2' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'intech_project_h_padding_right',
			[
			    'label' => esc_html__( 'Hadding margin Right', 'intechcore' ),
			    'type' => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range' => [
				  'px' => [
					'min' => 0,
					'max' => 500,
					'step' => 1,
				  ],
				  '%' => [
					'min' => 10,
					'max' => 100,
				  ],
			    ],
			    'selectors' => [
				  '{{WRAPPER}} .project-hadding h2' => 'margin-right: {{SIZE}}{{UNIT}};'
			    ],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
			    'name' => 'intech_project_typo',
			    'label' => esc_html__( ' Typography', 'intechcore' ),
			    'selector' => '{{WRAPPER}} .project-hadding h2',
			]
		);
		$this->add_responsive_control(
			'intech_project_hpadding',
			[
			    'label' => esc_html__( 'Padding', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'default' => [
				  'top' => '0',
				  'right' => '0',
				  'bottom' => '0',
				  'left' => '0',
				  'isLinked' => false
			    ],
			    'selectors' => [
				  '{{WRAPPER}} .project-haddings' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'intech_project_tab_menu_style',
			[
				'label' => esc_html__( 'Category Menu', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
			    'name' => 'intech_project_mtypo',
			    'label' => esc_html__( ' Typography', 'intechcore' ),
			    'selector' => '{{WRAPPER}} .project-menu ul li',
			]
		);
		$this->add_control(
			'intech_project_mcolor',
			[
				'label' => esc_html__( 'Menu color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .project-menu ul li' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'intech_project_macolor',
			[
				'label' => esc_html__( 'Active color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .project-menu ul li.active' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'intech_project_mbcolor',
				'label' => esc_html__( 'active Background', 'intechcore' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .project-menu ul li.active',
			]
		);
		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'intech_project_note',
			[
				'label' => __( '<strong>Hover Section</strong>', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
			]
		);
		$this->add_control(
			'intech_project_mhscolor',
			[
				'label' => esc_html__( 'Hover color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .project-menu ul li:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'intech_project_mbhcolor',
				'label' => esc_html__( 'Hover Background', 'intechcore' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .project-menu ul li:hover',
			]
		);
		$this->add_responsive_control(
			'intech_project_mmargin',
			[
			    'label' => esc_html__( 'Margin', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'default' => [
				  'top' => '5',
				  'right' => '5',
				  'bottom' => '5',
				  'left' => '5',
				  'isLinked' => false
			    ],
			    'selectors' => [
				  '{{WRAPPER}} .project-menu ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		);
		$this->add_responsive_control(
			'intech_project_mpadding',
			[
			    'label' => esc_html__( 'Padding', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'default' => [
				  'top' => '11',
				  'right' => '25',
				  'bottom' => '11',
				  'left' => '25',
				  'isLinked' => false
			    ],
			    'selectors' => [
				  '{{WRAPPER}} .project-menu ul li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_project_item_style',
			[
				'label' => esc_html__( 'Item', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'intech_project_item_icon_color',
			[
				'label' => esc_html__( 'Icon color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .project-video a i:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'intech_project_item_icon_hcolor',
			[
				'label' => esc_html__( 'Icon Hover color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#0b5be0',
				'selectors' => [
					'{{WRAPPER}} .project-video a:hover i:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'hr1',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'intech_project_note1',
			[
				'label' => __( '<strong>Button Normal Section</strong>', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
			]
		);
		$this->add_control(
			'intech_project_ib_color',
			[
				'label' => esc_html__( 'button Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .project-title a.theme-button' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'intech_project_ib_bg',
				'label' => esc_html__( 'Button Background Color', 'intechcore' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .project-title a.theme-button',
			]
		);
		$this->add_control(
			'hr2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'intech_project_note2',
			[
				'label' => __( '<strong>Button Hover Section</strong>', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
			]
		);
		$this->add_control(
			'intech_project_ib_hcolor',
			[
				'label' => esc_html__( 'button Hover Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .project-title a.theme-button:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'intech_project_ib_hbg',
				'label' => esc_html__( 'Button Background Color', 'intechcore' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .project-title a.theme-button:hover',
			]
		);
		$this->add_control(
			'hr3',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'intech_project_note3',
			[
				'label' => __( '<strong>image Hover background color</strong>', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'intech_project_im_hbg',
				'label' => esc_html__( 'Background Color', 'intechcore' ),
				'types' => [ 'classic', 'gradient' ],
				'default' => 'rgba(0, 0, 0, 0.52)',
				'selector' => '{{WRAPPER}} .project-signle:after',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_project_box_style',
			[
				'label' => esc_html__( 'Box', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'intech_project_box_margin',
			[
			    'label' => esc_html__( 'Margin', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top' => '95px',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => false
				],
			    'selectors' => [
				  '{{WRAPPER}} .project-boxs' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		);
		$this->add_responsive_control(
			'intech_project_box_padding',
			[
			    'label' => esc_html__( 'Padding', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => false
				],
			    	'selectors' => [
					'{{WRAPPER}} .project-boxs' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    	],
			    'separator' =>'before',
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render progress widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$dynamic_id = rand(1241, 3256);
		if($settings['intech_project_enable_sliders'] == 'yes' ){
			if($settings['intech_project_aplay'] == 'yes' ){
				$aplay = 'true';
			}else{
				$aplay = 'false';
			}
			if($settings['intech_project_nav'] == 'yes' ){
				$nav = 'true';
			}else{
				$nav = 'false';
			}
			echo '
			<script>
			jQuery(document).ready(function($) {
				"use strict";
				$("#project-'.esc_attr($dynamic_id).'").slick({
					autoplay:'.esc_attr($aplay).',
					arrows:'.esc_attr($nav).',
					slidesToShow:3,
					slidesToScroll:1,';
					if(!empty($settings['intech_project_aspeed'])){
						echo 'autoplaySpeed:'.esc_attr($settings['intech_project_aspeed']).',';
					}
					if(!empty($settings['intech_project_speed'])){
						echo 'speed:'.esc_attr($settings['intech_project_speed']).',';
					}
					echo '
					responsive: [
						{
						breakpoint: 1024,
							settings: {
								slidesToShow: 2,
								slidesToScroll: 2,
								
							}
						},
						{
							breakpoint: 992,
							settings: {
								slidesToShow: 2,
								slidesToScroll: 2
							}
						},
						{
							breakpoint: 600,
							settings: {
								slidesToShow: 1,
								slidesToScroll: 1
							}
						},
						{
							breakpoint: 480,
							settings: {
								slidesToShow: 1,
								slidesToScroll: 1
							}
						}
					]
				});
			});
			</script>';
		}
		if($settings['intech_project_style'] == '2' ){
			$dynamic_num = rand(35245545, 541541745);
		?>
			<script>
				jQuery(window).ready(function($) {
				'use strict';
				jQuery('.rafo-project-shorting li').on('click',function(){
					jQuery('.rafo-project-shorting li').removeClass('active');
					jQuery(this).addClass('active');
					var selector = jQuery(this).attr('data-filter');
					jQuery('.projectlist-<?php echo esc_attr($dynamic_num) ?>').isotope({
						filter:selector,
					});
				});
				});
				jQuery(window).on('load',function($) {
					'use strict';
					jQuery(".projectlist-<?php echo esc_attr($dynamic_num) ?>").isotope();
				});
			</script>
			<?php
		}
		if($settings['intech_project_style'] == '1'){
			$intech_pro_type = 'project-style-one';
		}elseif($settings['intech_project_style'] == '2'){
			$intech_pro_type = 'project-style-two';
		}else{
			$intech_pro_type = 'project-style-three';
		}
		if($settings['intech_project_style'] == '3'){
			$col_num = '12';
		}elseif($settings['intech_project_style'] == '2'){
			$col_num = '4';
		}elseif($settings['intech_project_enable_sliders'] != 'yes'){
			$col_num = '12';
		}else{
			$col_num = '4';
		}
		?>
		<div class="project-boxs">
			<div class="project-box <?php echo esc_attr($intech_pro_type); ?>">
				<div class="project-haddings <?php if($settings['intech_project_style'] == '1') : ?>container<?php endif; ?>">
					<div class="row">
						<div class="col-12 col-sm-12 col-md-12 col-lg-<?php echo esc_attr($col_num) ?>">
							<div class="project-hadding">
								<span><?php echo esc_html($settings['intech_project_stitle']); ?></span>
								<h2><?php echo esc_html($settings['intech_project_hadding']); ?></h2>
							</div>
						</div>
						<?php if($settings['intech_project_style'] == '2' ) :
						$intech_prjects = get_terms( 'project_cat' ); if( !empty($intech_prjects) && ! is_wp_error( $intech_prjects ) ) :
						?>
						<div class="d-flex flex-wrap align-content-center justify-content-xl-end col-12 col-sm-12 col-md-12 col-lg-8">
							<div class="project-menu">
								<ul class="rafo-project-shorting">
									<li class="active" data-filter="*"><?php esc_html_e('all','intechcore'); ?></li>
									<?php foreach($intech_prjects as $intech_prject) : ?>
									<li data-filter=".<?php echo esc_attr($intech_prject->slug) ?>"><?php echo esc_html($intech_prject->name) ?></li>
									<?php endforeach; ?>
								</ul>
							</div>
						</div>
						<?php endif; endif; ?>
					</div>
				</div>
				<div class="project-contents arrow-nav">
					<div class="project-items row projectlist-<?php if(!empty($settings['intech_project_style'] == '2' )){echo esc_attr($dynamic_num);} ?>"  id="project-<?php echo esc_attr($dynamic_id); ?>">
						<?php  global $post;
						$paged = get_query_var('paged') ? get_query_var('paged') : 1;
						$p = new \WP_Query(array(
						'posts_per_page' => esc_attr($settings['intech_project_per_post']),
						'post_type' => 'project',
						'paged' => $paged
						));
						while($p->have_posts()) : $p->the_post();
							$intech_idd = get_the_ID();
							$intech_pro_meta = get_post_meta($intech_idd, 'intech_project_meta', true);
					    		$project_catagory = get_the_terms( get_the_ID(), 'project_cat' );
						if ( $project_catagory && ! is_wp_error( $project_catagory ) ) {
					   	 	$project_cat_list = array();
					    	foreach ( $project_catagory as $project_cat ) {
					        	$project_cat_list[] = $project_cat->slug;
					   	}
							$project_catshow = join( ", ", $project_cat_list );
						}else{
							$project_catshow = '';
					  	}
						?>
						<div class="item <?php if( ! empty($settings['intech_project_style'] !== "1" ) || !empty( $settings['intech_project_enable_sliders'] !== "yes" ) ) : ?>service-3 col-12 col-sm-<?php if( $settings['intech_project_style'] == '1' && $settings['intech_project_enable_sliders'] != 'yes' ) : ?>12<?php else : ?>6<?php endif; ?>  col-md-6 col-lg-4 col-xl-4 <?php echo esc_attr($project_catshow) ?><?php endif; ?>">
							<div class="project-signle">
								<?php
								if($settings['intech_project_style'] == '2' ){
									the_post_thumbnail('intech-project-image2');
								}else{
									the_post_thumbnail('intech-project-image');
								}
								?>
								<?php if(!empty( $settings['intech_project_style'] == '3' )) : ?>
								<div class="project-content">
									<div class="pro-left">
										<?php $intech_prjects = get_terms( 'project_cat' ); if( !empty($intech_prjects) && ! is_wp_error( $intech_prjects ) ) : ?>
										<ul>
										<?php foreach($intech_prjects as $intech_prject) : ?>
											<li><?php echo esc_html($intech_prject->name) ?></li>
										<?php endforeach; ?>
										</ul>
										<?php endif; ?>
										<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									</div>
									<div class="pro-right">
										<a href="<?php the_permalink(); ?>" class="theme-button">
											<i class="flaticon-right-arrow"></i>
										</a>
									</div>
								</div>
								<?php else : ?>
								<div class="project-video">
									<a href="#" data-video-url="<?php echo esc_url($intech_pro_meta['intech_pro_video_link']); ?>" class="popUp" style="cursor: pointer;">
									<i aria-hidden="true" class="flaticon-play-button-1"></i></a>
								</div>
								<div class="project-title">
									<div class="theme-buttons">
										<a href="<?php the_permalink(); ?>" class="theme-button">
											<?php the_title(); ?><i class="flaticon-right-arrow"></i>
										</a>
									</div>
								</div>
								<?php endif; ?>
							</div>
						</div>
						<?php endwhile; wp_reset_postdata(); wp_reset_query();?>
					</div>
					<?php if($settings['intech_project_pagi'] == 'yes') : ?>
					<div class="cpaginations">
						<?php intech_paginate_nav( $p ); ?>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_project_Widget );
