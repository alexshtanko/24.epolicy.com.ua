<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor progress widget.
 *
 * Elementor widget that displays an escalating progress bar.
 *
 * @since 1.0.0
 */
class intech_clients_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve progress widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'intech-client';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve progress widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'intech Client', 'intechcore' );
	}

    
	public function get_categories() {
		return [ 'intechcore' ];
	}
    
	/**
	 * Get widget icon.
	 *
	 * Retrieve progress widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-t-letter';
	}
	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'intech', 'client' ];
	}

	/**
	 * Register progress widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'intech_clients_contens',
			[
				'label' => esc_html__( 'Content', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
            $repeater = new \Elementor\Repeater();
            
            $repeater->add_control(
			'intech_client_logo', [
				'label' => esc_html__( 'Client Logo', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'intech_clili_enable',
			[
			    'label'         => esc_html__( 'Enable Link', 'intechcore' ),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'On', 'intechcore' ),
			    'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    'return_value'  => 'yes',
			    'default'       => 'yes',
			]
		);
		$repeater->add_control(
			'intech_client_links',
			[
				'label' => esc_html__( 'Select Link', 'intechcore' ),
				'type'  => Controls_Manager::SELECT,
				'default'	=> 'extranal',
				'options' => [
					'no' => esc_html__( 'Select Options', 'intechcore' ),
					'extranal' => esc_html__( 'Extranal', 'intechcore' ),
					'page' =>  esc_html__( 'Page', 'intechcore' ),
				],
				'condition' 	=> [
                        	'intech_clili_enable' => 'yes',
                  	]
			]
		);
		$repeater->add_control(
			'intech_client_extranal',
			[
				'label' => esc_html__( 'Extranal Link', 'intechcore' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'condition' => array(
					'intech_client_links' => 'extranal',
					'intech_clili_enable' => 'yes',
				),
				'placeholder' => esc_html__( 'Add Extranal Link', 'intechcore' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'intech_client_page_link',
			[
				'label' => esc_html__( 'Page Link', 'intechcore' ),
				'type' => Controls_Manager::SELECT,
				'options' => intech_page_list(),
				'condition' => array(
					'intech_client_links' => 'page',
					'intech_clili_enable' => 'yes',
				),
			]
		);
		$this->add_control(
			'intech_client_slides',
			[
				'label' => esc_html__( 'Clients', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'intech_client_logo' => esc_html__( 'Client Iamge', 'intechcore' ),
					],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'intech_clients_config',
			[
				'label' => esc_html__( 'Slide Configaration', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'intech_client_slide_on',
			[
				'label'         => esc_html__( 'Enable Slider ', 'intechcore' ),
			    	'type'          => Controls_Manager::SWITCHER,
			    	'label_on'      => esc_html__( 'On', 'intechcore' ),
			    	'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    	'return_value'  => 'yes',
			    	'default'       => 'no',
			]
		);
		$this->add_control(
			'intech_clsl_loop',
			[
			    'label'         => esc_html__( 'Enable Loop ', 'intechcore' ),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'On', 'intechcore' ),
			    'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    'return_value'  => 'yes',
			    'default'       => 'no',
			    'condition' 	=> [
                        	'intech_client_slide_on' => 'yes',
                  	]
			]
		);
		$this->add_control(
			'intech_clsl_speed',
			[
				'label' 	=> esc_html__( 'Slide Speed', 'intechcore' ),
			    	'type' 	=> Controls_Manager::NUMBER,
			    	'min' 	=> 500,
			    	'max' 	=> 5000,
			    	'step' 	=> 10,
			    	'default' 	=> 1000,
				'condition' => array(
					'intech_client_slide_on' 	=> 'yes',
					'intech_clsl_loop' 		=> 'yes',
					
				)
			]
		);
		$this->add_control(
			'intech_clsl_aloop',
			[
			    'label'         => esc_html__( 'Enable Auto Loop ', 'intechcore' ),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'On', 'intechcore' ),
			    'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    'return_value'  => 'yes',
			    'default'       => 'no',
			    'condition' 	=> [
                        	'intech_clsl_loop' => 'yes',
                  	]
			]
		);
		$this->add_control(
			'intech_clsl_aspeed',
			[
				'label' 	=> esc_html__( 'Slide auto Speed', 'intechcore' ),
			    	'type' 	=> Controls_Manager::NUMBER,
			    	'min' 	=> 500,
			    	'max' 	=> 5000,
			    	'step' 	=> 50,
			    	'default' 	=> 1000,
			   	'condition' => array(
					'intech_clsl_aloop' => 'yes',
					'intech_clsl_loop' 	=> 'yes',
					'intech_client_slide_on' 	=> 'yes',
					
				)
			]
		);
		$this->add_control(
			'intech_clsl_nav',
			[
			    'label'         => esc_html__( 'Enable Nav ', 'intechcore' ),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'On', 'intechcore' ),
			    'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    'return_value'  => 'yes',
			    'default'       => 'no',
			    'condition' 	=> [
                        	'intech_client_slide_on' => 'yes',
                  	]
			]
		);
		$this->add_control(
			'intech_clsl_dot',
			[
			    'label'         => esc_html__( 'Enable Dots ', 'intechcore' ),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'On', 'intechcore' ),
			    'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    'return_value'  => 'yes',
			    'default'       => 'no',
			    'condition' 	=> [
                        	'intech_client_slide_on' => 'yes',
                  	]
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'intech_client_styles',
			[
				'label' => esc_html__( 'Style', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'intech_client_margin',
			[
			    'label' => esc_html__( 'Margin', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				  '{{WRAPPER}} .client-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		  );        
		  $this->add_responsive_control(
			'intech_client_padding',
			[
			    'label' => esc_html__( 'Padding', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				  '{{WRAPPER}} .client-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		  );   
		  $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'intechcore' ),
				'selector' => '{{WRAPPER}} .client-section',
			]
		);
		$this->end_controls_section();
	
	}

	/**
	 * Render progress widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$dynamic_id = rand(1241, 3256);
		if($settings['intech_client_slide_on'] == 'yes' ){
			if($settings['intech_clsl_dot'] == 'yes' ){
				$dots = 'true';
			}else{
				$dots = 'false';
			}
			if($settings['intech_clsl_nav'] == 'yes' ){
				$nav = 'true';
			}else{
				$nav = 'false';
			}
			if($settings['intech_clsl_aloop'] == 'yes' ){
				$aloop = 'true';
			}else{
				$aloop = 'false';
			}
			if($settings['intech_clsl_loop'] == 'yes' ){
				$loop = 'true';
			}else{
				$loop = 'false';
			}
			echo '
			<script>
			jQuery(document).ready(function($) {
				"use strict";
				$("#clients-'.esc_attr($dynamic_id).'").slick({
					slidesToShow: 5,
					slidesToScroll: 1,
					dots: '.esc_attr($dots).',
					infinite: '.esc_attr($loop).',
					autoplay: '.esc_attr($aloop).',
					arrows: '.esc_attr($nav).',';
					if($aloop == 'true'){
					echo 'speed: '.esc_attr($settings['intech_clsl_speed']).',';
					}
					if($aloop == 'true'){
					echo 'autoplaySpeed: '.esc_attr($settings['intech_clsl_aspeed']).',';
					}
					echo '
					responsive: [
						{
						breakpoint: 1024,
							settings: {
								slidesToShow: 3,
								slidesToScroll: 3,
								infinite: true,
								dots: true
							}
						},
						{
							breakpoint: 600,
							settings: {
								slidesToShow: 2,
								slidesToScroll: 2
							}
						},
						{
							breakpoint: 480,
							settings: {
								slidesToShow: 1,
								slidesToScroll: 1
							}
						}
					]
				});
			});
			</script>';
            }
		?>
		<?php if( !empty( $settings['intech_client_slides']) ) : ?>
		<div class="client-section">
			<div class="client-items" id="clients-<?php echo esc_attr($dynamic_id); ?>">
			<?php foreach ( $settings['intech_client_slides'] as $intech_client_slide  ) :
			if( $intech_client_slide['intech_client_links'] == 'page' ){
				$clientource = get_page_link( $intech_client_slide['intech_client_page_link'] );
			}else{
				$clientource =  $intech_client_slide['intech_client_extranal'];
			}
			?>
			<div class="item">
				<?php if(!empty( $intech_client_slide['intech_clili_enable'] == true )) : ?>
				<a href="<?php echo esc_url($clientource); ?>">
					<?php echo wp_get_attachment_image( $intech_client_slide['intech_client_logo']['id'], 'large' ); ?>
				</a>
				<?php else : ?>
					<?php echo wp_get_attachment_image( $intech_client_slide['intech_client_logo']['id'], 'large' ); ?>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_clients_Widget );