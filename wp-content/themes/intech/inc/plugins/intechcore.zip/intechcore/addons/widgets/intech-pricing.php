<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor progress widget.
 *
 * Elementor widget that displays an escalating progress bar.
 *
 * @since 1.0.0
 */
class intech_pricing_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve progress widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'intech-pricing';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve progress widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'intech Pricing Table', 'intechcore' );
	}

    
	public function get_categories() {
		return [ 'intechcore' ];
	}
    
	/**
	 * Get widget icon.
	 *
	 * Retrieve progress widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-t-letter';
	}
	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'intech', 'Pricing' ];
	}

	/**
	 * Register progress widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		
		$this->start_controls_section(
			'intech_pricing_section',
			[
				'label' => esc_html__( 'Content', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'intech_pricing_icon',
			[
			    'label' =>esc_html__('Icon','intechcore'),
			    'type'=>Controls_Manager::ICON,
			    'label_block' => true,
			]
		  );
		$this->add_control(
			'intech_pricing_title',
			[
			    'label' => esc_html__( 'Title', 'intechcore' ),
			    'type'          => Controls_Manager::TEXT,
			    'default'       => esc_html__('Pricing Title','intechcore'),
			]
		);
		$this->add_control(
			'intech_pricing_title_label',
			[
			    'label' => esc_html__( 'Title Label', 'intechcore' ),
			    'type'          => Controls_Manager::TEXT,
			    'default'       => esc_html__('label','intechcore'),
			]
		);
		$this->add_control(
			'intech_pricing_month',
			[
			    'label' => esc_html__( 'Month/Year', 'intechcore' ),
			    'type'          => Controls_Manager::TEXT,
			    'default'       => esc_html__('Per year','intechcore'),
			]
		);
		$this->add_control(
			'intech_pricing_money',
			[
			    'label' => esc_html__( 'Amount with Currency ', 'intechcore' ),
			    'type'          => Controls_Manager::TEXT,
			    'default'       => '$99.99',
			]
		);
		$this->add_control(
			'intech_pricing_dec',
			[
			    'label' => esc_html__( 'Amount with Currency ', 'intechcore' ),
			    'type' => Controls_Manager::WYSIWYG,
			    'default'       => wp_kses(
				    __('
				    <ul>
				    	<li>Brandwidth: <strong>2GB</strong></li>
				    	<li>Clint & Product: <strong>2GB</strong></li>
				    	<li>onlinespace: <strong>2GB</strong></li>
				    	<li>Domain: <strong>2</strong></li>
				    	<li>Hidden Fees: <strong>0</strong></li>
				    </ul>','intechcore'),
				    array(
					'ul' => array(),
					'li' => array(),
					'strong' => array(),
					'span' => array(),
				    )
			    ),
			]
		);
		$this->add_control(
			'intech_pricing_link',
			[
			    'label' => esc_html__( 'button Link', 'intechcore' ),
			    'type'          => Controls_Manager::TEXT,
			]
		);
		$this->add_control(
			'intech_pricing_link_text',
			[
			    'label' => esc_html__( 'Button Text', 'intechcore' ),
			    'type'        => Controls_Manager::TEXT,
			    'default'	=> esc_html('Select plan','intechcore'),
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_pricing_border_styles',
			[
			    'label' => esc_html__( 'Pricing box', 'intechcore' ),
			    'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'intech_pricing_border',
				'label' => esc_html__( 'Border', 'intechcore' ),
				'selector' => '{{WRAPPER}} .pricing-box',
			]
		);
		$this->add_responsive_control(
			'intech_pricing_alignment',
			[
				'label' => esc_html__( 'Alignment', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'intechcore' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'intechcore' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'intechcore' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pricing-box' => 'text-align: {{VALUE}};',
				],
				'default' => 'center',
				'toggle' => true,
			]
		);
		$this->add_responsive_control(
			'intech_pricing_box_margin',
			[
			    'label' => esc_html__( 'Margin', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				  '{{WRAPPER}} .pricing-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		);
		$this->add_responsive_control(
			'intech_pricing_box_padding',
			[
			    'label' => esc_html__( 'Padding', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				  '{{WRAPPER}} .pricing-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_pricing_icon_styles',
			[
			    'label' => esc_html__( 'Pricing Icon', 'intechcore' ),
			    'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'intech_pricing_icon_font',
			[
				'label' => esc_html__( 'Font Icon Size', 'intechcore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 40,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 55,
				],
				'selectors' => [
					'{{WRAPPER}} .pricing-icon i:before' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'intech_pricing_icon_font_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default'	=>'#0a5be0',
				'selectors' => [
					'{{WRAPPER}} .pricing-icon i:before' => 'color: {{VALUE}};',
				],
			]
		); 
		$this->add_responsive_control(
			'title_color',
			[
				'label' => esc_html__( 'icon Background', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-icon i' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'intech_pricing_icon_padding',
			[
				'label' => esc_html__( 'Top', 'intechcore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => -50,
						'max' => 200,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => -27,
				],
				'selectors' => [
					'{{WRAPPER}} .pricing-icon' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_pricing_header_styles',
			[
			    'label' => esc_html__( 'Pricing Header', 'intechcore' ),
			    'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs('intech_pricing_header_tabs');

        	$this->start_controls_tab( 'intech_pricing_header_title_tab',
			[
				'label' => esc_html__( 'Title', 'intechcore' ),
			]
		);
		$this->add_control(
			'intech_pricing_title_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default'	=>'#000000',
				'selectors' => [
					'{{WRAPPER}} .pricing-title h2' => 'color: {{VALUE}};',
				],
			]
		); 
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'intech_pricing_title_typo',
				'selector' => '{{WRAPPER}} .pricing-title h2',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab( 'intech_pricing_header_year_tab',
			[
				'label' => esc_html__( 'Year', 'intechcore' ),
			]
		);
		$this->add_control(
			'intech_pricing_year_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default'	=>'#0a5be0',
				'selectors' => [
					'{{WRAPPER}} .pricing-year h4' => 'color: {{VALUE}};',
				],
			]
		); 
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'intech_pricing_year_typo',
				'selector' => '{{WRAPPER}} .pricing-year h4',
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab( 'intech_pricing_header_amount_tab',
			[
				'label' => esc_html__( 'Amount', 'intechcore' ),
			]
		);
		$this->add_control(
			'intech_pricing_amount_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default'	=>'#000000',
				'selectors' => [
					'{{WRAPPER}} .pricing-amount h1' => 'color: {{VALUE}};',
				],
			]
		); 
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'intech_pricing_amount_typo',
				'selector' => '{{WRAPPER}} .pricing-amount h1',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_control(
			'line2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'intech_pricing_header_margin',
			[
			    'label' => esc_html__( 'Margin', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				  '{{WRAPPER}} .pricing-header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		);
		$this->add_responsive_control(
			'intech_pricing_header_padding',
			[
			    'label' => esc_html__( 'Padding', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				  '{{WRAPPER}} .pricing-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			    'separator' =>'before',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_pricing_body_styles',
			[
			    'label' => esc_html__( 'Pricing Body', 'intechcore' ),
			    'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'intech_pricing_body_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default'	=>'#798795',
				'selectors' => [
					'{{WRAPPER}} .pricing-body ul li' => 'color: {{VALUE}};',
				],
			]
		); 
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'intech_pricing_body_typo',
				'selector' => '{{WRAPPER}} .pricing-body',
			]
		);
		$this->add_control(
			'intech_pricing_body_border_color',
			[
				'label' => esc_html__( 'border Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default'	=>'#e6e6e6',
				'selectors' => [
					'{{WRAPPER}} .pricing-body ul li' => 'border-color: {{VALUE}};',
				],
			]
		); 
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_pricing_footer_styles',
			[
			    'label' => esc_html__( 'Pricing Footer', 'intechcore' ),
			    'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'intech_pricing_footer_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default'	=>'#798795',
				'selectors' => [
					'{{WRAPPER}} .pricing-footer a.theme-button' => 'color: {{VALUE}};',
				],
			]
		); 
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'intech_pricing_footer_bg',
				'label' => esc_html__( 'Button Background', 'intechcore' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pricing-footer a.theme-button',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'intech_pricing_footer_typo',
				'selector' => '{{WRAPPER}} .pricing-footer a.theme-button',
			]
		);
		$this->add_control(
			'line3',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'intech_note1',
			[
				'label' => __( '<strong>Hover background Color</strong>', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'content_classes' => 'note-message',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'intech_pricing_footer_hbg',
				'label' => esc_html__( 'Button Hover Background', 'intechcore' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pricing-footer a.theme-button:hover',
			]
		);
		$this->add_control(
			'intech_pricing_footer_hcolor',
			[
				'label' => esc_html__( 'Hover Color', 'intechcore' ),
				'type' => Controls_Manager::COLOR,
				'default'	=>'#ffffff',
				'selectors' => [
					'{{WRAPPER}} .pricing-footer a.theme-button:hover' => 'color: {{VALUE}};',
				],
			]
		); 
		$this->add_responsive_control(
			'intech_pricing_footer_margin',
			[
			    'label' => esc_html__( 'Margin', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				  '{{WRAPPER}} .pricing-footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],                
			    'default' => [
				  'top' => '0',
				  'right' => '0',
				  'bottom' => '0',
				  'left' => '0',
				  'isLinked' => false
			    ],
			    'separator' =>'before',
			]
		);
		$this->add_responsive_control(
			'intech_pricing_footer_padding',
			[
			    'label' => esc_html__( 'Padding', 'intechcore' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				  '{{WRAPPER}} .pricing-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],                
			    'default' => [
				  'top' => '70',
				  'right' => '0',
				  'bottom' => '70',
				  'left' => '0',
				  'isLinked' => false
			    ],
			    'separator' =>'before',
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render progress widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		?>
		<div class="pricing-box">
			<?php if(!empty($settings['intech_pricing_icon'] )) : ?>
			<div class="pricing-icon">
			<i class="<?php echo esc_attr($settings['intech_pricing_icon']); ?>"></i>
			</div>
			<?php endif; ?>
			<div class="pricing-header">
				<div class="pricing-title">
			<h2><?php echo esc_html($settings['intech_pricing_title']); ?><?php if(!empty($settings['intech_pricing_title_label'])) : ?><label><?php echo esc_html($settings['intech_pricing_title_label']) ?></label><?php endif; ?></h2>
				</div>
				<div class="pricing-year">
					<h4><?php echo esc_html($settings['intech_pricing_month']); ?></h4>
				</div>
				<div class="pricing-amount">
					<h1><?php echo esc_html($settings['intech_pricing_money']) ?></h1>
				</div>
			</div>
			<div class="pricing-body">
				<?php echo wp_kses_post(wpautop($settings['intech_pricing_dec'] )); ?>
			</div>
			<div class="pricing-footer">
				<div class="theme-buttons">
					<a href="<?php echo esc_url($settings['intech_pricing_link']) ?>" class="theme-button"><?php echo esc_html($settings['intech_pricing_link_text']); ?><i class="flaticon-right-arrow"></i></a>
				</div>
			</div>
		</div>
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_pricing_Widget );