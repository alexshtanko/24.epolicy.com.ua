<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor progress widget.
 *
 * Elementor widget that displays an escalating progress bar.
 *
 * @since 1.0.0
 */
class intechSearch_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return 'intech-search';
    }
    
    public function get_title() {
        return esc_html__( 'intech Search', 'intechcore' );
    }

    public function get_icon() {
        return 'eicon-site-search';
    }
    
    public function get_categories() {
        return [ 'intechhf' ];
    }

    public function get_menus(){
        $list = [];
        $menus = wp_get_nav_menus();
        foreach($menus as $menu){
            $list[$menu->slug] = $menu->name;
        }

        return $list;
    }

	protected function _register_controls() {
        // Start Menu Setting        
			$this->start_controls_section( 
				'section_logo_setting',
	            [
	                'label' => esc_html__('Logo Setting', 'intechcore'),
	            ]
	        );	
			
			$this->add_control(
				'icon_search',
				[			        
			        'label' => esc_html__('Icon Search', 'intechcore'),
			        'type' => \Elementor\Controls_Manager::ICONS,
			        'default' => [
			            'value' => 'fas fa-search',
			            'library' => 'fa-solid',
			        ],
			    ]
			);			

			$this->end_controls_section();
        // /.End Menu Setting		

		// Start Button Search Style 
	        $this->start_controls_section( 
	        	'section_style_button_search',
	            [
	                'label' => esc_html__( 'Button Search', 'intechcore' ),
	                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
	            ]
	        );

	        $this->add_control(
				'button_search_position',
				[
					'label' => esc_html__( 'Alignment', 'intechcore' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'intech-alignment-left'    => [
							'title' => esc_html__( 'Left', 'intechcore' ),
							'icon' => 'eicon-text-align-left',
						],
						'intech-alignment-center' => [
							'title' => esc_html__( 'Center', 'intechcore' ),
							'icon' => 'eicon-text-align-center',
						],
						'intech-alignment-right' => [
							'title' => esc_html__( 'Right', 'intechcore' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'default' => 'intech-alignment-left',
				]
			);

	        $this->add_responsive_control(
				'btn_search_font_size',
				[
					'label' => esc_html__( 'Font size', 'intechcore' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 1,
	                    ],
	                    'em' => [
							'min' => 0,
							'max' => 10,
							'step' => 1,
						],
	                ],
					'default' => [
						'size' => 20,
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .intech-widget-search .intech-icon-search' => 'font-size: {{SIZE}}{{UNIT}};',
					],					
				]
			);

			$this->add_control(
				'btn_search_padding',
				[
					'label' => esc_html__( 'Padding', 'intechcore' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em' ],
					'default' => [
	                    'top' => 8,
	                    'right' => 16,
	                    'bottom' => 8,
	                    'left' => 16,
	                    'unit' => 'px',
	                ],
					'selectors' => [
						'{{WRAPPER}} .intech-widget-search .intech-icon-search' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'btn_search_margin',
				[
					'label' => esc_html__( 'Margin', 'intechcore' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .intech-widget-search .intech-icon-search' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'btn_search_box_shadow',
					'label' => esc_html__( 'Box Shadow', 'intechcore' ),
					'selector' => '{{WRAPPER}} .intech-widget-search .intech-icon-search',
				]
			);

			$this->start_controls_tabs( 'btn_search_tabs' );				

				$this->start_controls_tab( 
					'btn_search_normal_tab',
					[
						'label' => esc_html__( 'Normal', 'intechcore' ),						
					]
					);

			        $this->add_control(
						'btn_search_background',
						[
							'label' => esc_html__( 'Background', 'intechcore' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => 'rgba(255,255,255,0)',
							'selectors' => [
								'{{WRAPPER}} .intech-widget-search .intech-icon-search' => 'background-color: {{VALUE}}',
							],
						]
					);

			        $this->add_control(
						'btn_search_color',
						[
							'label' => esc_html__( 'Color', 'intechcore' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '#000000',
							'selectors' => [
								'{{WRAPPER}} .intech-widget-search .intech-icon-search' => 'color: {{VALUE}}',
							],
						]
					);	

					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'btn_search_border',
							'label' => esc_html__( 'Border', 'intechcore' ),
							'selector' => '{{WRAPPER}} .intech-widget-search .intech-icon-search',
						]
					);

					$this->add_control(
						'btn_search_border_radius',
						[
							'label' => esc_html__( 'Border Radius', 'intechcore' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em' ],
							'selectors' => [
								'{{WRAPPER}} .intech-widget-search .intech-icon-search' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);		
				
				$this->end_controls_tab();

				$this->start_controls_tab( 
			    	'btn_search_hover_tab',
					[
						'label' => esc_html__( 'Hover', 'intechcore' ),
					]
					);	

					$this->add_control(
						'btn_search_background_hover',
						[
							'label' => esc_html__( 'Background', 'intechcore' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => 'rgba(255,255,255,0)',
							'selectors' => [
								'{{WRAPPER}} .intech-widget-search .intech-icon-search:hover' => 'background-color: {{VALUE}}',
							],
						]
					);

					$this->add_control(
						'btn_search_color_hover',
						[
							'label' => esc_html__( 'Color', 'intechcore' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '#0b5be0',
							'selectors' => [
								'{{WRAPPER}} .intech-widget-search .intech-icon-search:hover' => 'color: {{VALUE}}',
							],
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'btn_search_border_hover',
							'label' => esc_html__( 'Border', 'intechcore' ),
							'selector' => '{{WRAPPER}} .intech-widget-search .intech-icon-search:hover',
						]
					);				
				
				$this->end_controls_tab();

	        $this->end_controls_tabs();

	        $this->end_controls_section();
	    // /.End Button Search Style

	    // Start Form Search Style 
	        $this->start_controls_section( 
	        	'section_style_form_search',
	            [
	                'label' => esc_html__( 'Form Search', 'intechcore' ),
	                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
	            ]
	        );

	        $this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'form_search_background',
					'label' => esc_html__( 'Background', 'intechcore' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .intech-widget-search .intech-modal-search-panel',
				]
			);

			$this->add_control(
				'form_search_color',
				[
					'label' => esc_html__( 'Color', 'intechcore' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#ffffff',
					'selectors' => [
						'{{WRAPPER}} .intech-widget-search .search-field' => 'color: {{VALUE}}',
						'{{WRAPPER}} .intech-widget-search .search-field' => 'border-color: {{VALUE}}',
						'{{WRAPPER}} .intech-widget-search .search-submit' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'form_search_placeholder_color',
				[
					'label' => esc_html__( 'Placeholder Color', 'intechcore' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#ffffff',
					'selectors' => [
						'{{WRAPPER}} .intech-widget-search .search-field::placeholder' => 'color: {{VALUE}}',
					],
				]
			);

	        $this->end_controls_section();
	    // /.End Form Search Style
	}

	protected function render($instance = []) {
		$settings = $this->get_settings_for_display();
		$class = $icon_search = '';
		$class .= $settings['button_search_position'];

		if ( $settings['icon_search']['value'] != '' ) {
			if ( !empty( $settings['icon_search']['value']['url'] ) ) {
				$icon_search = sprintf(
		           '<img class="logo_svg" src="%1$s" alt="%2$s"/>',
		             $settings['icon_search']['value']['url'],
		             $settings['icon_search']['value']['id']
		            
		         ); 
			} else {
				$icon_search = sprintf(
		             '<i class="%1$s"></i>',
		            $settings['icon_search']['value']
		        );  
			}
		}
		
		echo sprintf ( 
			'<div class="intech-widget-search %1$s">
				<button class="intech-icon-search">%2$s</button>
				<div class="intech-modal-search-panel">
					<div class="search-panel">
						<form role="search" method="get" class="intech-search-form" action="%3$s">
		                    <input type="search" class="search-field" placeholder="Search…" value="%4$s" name="s">
		                    <button type="submit" class="search-submit"><i aria-hidden="true" class="fas fa-search"></i></button>
		                </form>
					</div>
					<button class="intech-close-modal"></button>
				</div>				
			</div>',
			$class,
			$icon_search,
			esc_url(home_url( '/' )),
			get_search_query()
			
        );
	}
	protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new intechSearch_Widget );