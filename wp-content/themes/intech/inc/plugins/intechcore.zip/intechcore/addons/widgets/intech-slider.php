<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor progress widget.
 *
 * Elementor widget that displays an escalating progress bar.
 *
 * @since 1.0.0
 */
class intech_slider_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve progress widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'intech-slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve progress widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'intech Slider', 'intechcore' );
	}

    
	public function get_categories() {
		return [ 'intechcore' ];
	}
    
	/**
	 * Get widget icon.
	 *
	 * Retrieve progress widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-t-letter';
	}
	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'intech', 'slider' ];
	}

	/**
	 * Register progress widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'intech_slider_section',
			[
				'label' => esc_html__( 'Content', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();
       
        $repeater->add_control(
			'intech_slider_image',
			[
				'label' => __( 'Choose Image', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        $repeater->add_control(
            'intech_slider_stitle', [
                'label' => esc_html__( 'Small Title', 'intechcore' ),
                'type' => Controls_Manager::TEXT,
                'show_label' => true,
            ]
        );
        $repeater->add_control(
            'intech_slider_title', [
                'label' => esc_html__( 'Title', 'intechcore' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => __( 'Choose Your IT Solution For Good Business!' , 'intechcore' ),
                'show_label' => true,
            ]
        );
        $repeater->add_control(
            'intech_slider_content', [
                'label' => esc_html__( 'Content', 'intechcore' ),
                'type' => Controls_Manager::WYSIWYG,
                'default' => __( 'Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh.sagittis magna.From helpdesk.' , 'intechcore' ),
                'show_label' => true,
            ]
        );
        $repeater->add_control(
			'intech_slider_btn_enable',
			[
				'label' => __( 'Button Enable', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'your-plugin' ),
				'label_off' => __( 'Hide', 'your-plugin' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
        $repeater->add_control(
			'intech_slider_btns',
			[
				'label' => esc_html__( 'Select Link', 'intechcore' ),
				'type'  => Controls_Manager::SELECT,
				'default'	=> 'extranal',
				'options' => [
					'extranal' => esc_html__( 'Extranal', 'intechcore' ),
					'page' =>  esc_html__( 'Page', 'intechcore' ),
				],
				'label_block' => true,
				'condition' => [
					'intech_slider_btn_enable' => 'yes',
				],
			]
		);
        $repeater->add_control(
			'intech_slider_extral',
			[
				'label' => esc_html__( 'Extranal Link', 'intechcore' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'condition' => [
					'intech_slider_btns' => 'extranal',
				],
				'placeholder' => esc_html__( 'Add Extranal Link', 'intechcore' ),
				'label_block' => true,
				'condition' => [
					'intech_slider_btn_enable' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'intech_slider_page_link',
			[
				'label' => esc_html__( 'Page Link', 'intechcore' ),
				'type' => Controls_Manager::SELECT,
				'options' => intech_page_list(),
				'condition' => [
					'intech_slider_btns' => 'page',
				],
				'label_block' => true,
				'condition' => [
					'intech_slider_btn_enable' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'intech_slider_btn_text',
			[
				'label' => esc_html__( 'Buttn Text', 'intechcore' ),
				'type' => Controls_Manager::TEXT,
				'default'	=> esc_html__( 'Read More', 'intechcore' ),
				'label_block' => true,
				'condition' => [
					'intech_slider_btn_enable' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'intech_slider_bideo_enable',
			[
				'label' => __( 'Enable Video button', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'intechcore' ),
				'label_off' => __( 'Hide', 'intechcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$repeater->add_control(
			'intech_slider_video_link',
			[
				'label' => __( 'Video Link', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'intech_slider_bideo_enable' => 'yes',
				],
				'label_block' => true,
				'default' => 'https://www.youtube.com/watch?v=f3NWvUV8MD8',
			]
		);
		$repeater->add_control(
			'intech_slider_video_text',
			[
				'label' => __( 'Video Text', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'condition' => [
					'intech_slider_bideo_enable' => 'yes',
				],
				'label_block' => true,
			]
		);
        $this->add_control(
            'intech_sliders',
            [
                'label' => esc_html__( 'Slider List', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'intech_slider_title' => __( 'Choose Your IT Solution For Good Business!', 'intechcore' ),
                        'intech_slider_content' => __('Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh.sagittis magna.From helpdesk. ', 'intechcore' ),
                        'intech_slider_btn_text' =>  __( 'Read More', 'intechcore' ),
                        'intech_slider_video_text' => __( 'Watch Our Video', 'intechcore' ),
                        'intech_slider_video_link' =>  'https://www.youtube.com/watch?v=f3NWvUV8MD8',
                    ],
                ],
            ]
        );
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_slider_setting',
			[
				'label' => esc_html__( 'Settings', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_responsive_control(
			'intech_slider_height',
			[
				'label' => esc_html__( 'Icon Radius', 'intechcore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 300,
						'max' => 1000,
						'step' => 1,
					]
				],
				'default' => [
					'unit' => 'px',
					'size' => 800,
				],
				'selectors' => [
					'{{WRAPPER}} .intech-slide-item' => 'height: {{SIZE}}{{UNIT}};'
				],
			]
		);
		$this->add_control(
			'intech_slider_slide_on',
			[
				'label'         => esc_html__( 'Enable Slider', 'intechcore' ),
			    	'type'          => Controls_Manager::SWITCHER,
			    	'label_on'      => esc_html__( 'On', 'intechcore' ),
			    	'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    	'return_value'  => 'yes',
			    	'default'       => 'yes',
			]
		);
		$this->add_control(
			'intech_slide_loop',
			[
			    'label'         => esc_html__( 'Enable Loop ', 'intechcore' ),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'On', 'intechcore' ),
			    'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    'return_value'  => 'yes',
			    'default'       => 'yes',
			    'condition' 	=> [
                        	'intech_slider_slide_on' => 'yes',
                  	]
			]
		);
		$this->add_control(
			'intech_slide_aloop',
			[
			    'label'         => esc_html__( 'Enable Auto Loop ', 'intechcore' ),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'On', 'intechcore' ),
			    'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    'return_value'  => 'yes',
			    'default'       => 'yes',
			    'condition' 	=> [
                        'intech_slide_loop' => 'yes',
                  	]
			]
		);
		$this->add_control(
			'intech_slide_aspeed',
			[
				'label' 	=> esc_html__( 'Slide auto Speed', 'intechcore' ),
			    	'type' 	=> Controls_Manager::NUMBER,
			    	'min' 	=> 200,
			    	'max' 	=> 5000,
			    	'step' 	=> 50,
			    	'default' 	=> 1000,
			   	'condition' => array(
					'intech_slide_aloop' 		=> 'yes',
					'intech_slide_loop' 		=> 'yes',
					'intech_slider_slide_on' 	=> 'yes',
					
				)
			]
		);
		$this->add_control(
			'intech_slide_speed',
			[
				'label' 	=> esc_html__( 'Slide Speed', 'intechcore' ),
			    	'type' 	=> Controls_Manager::NUMBER,
			    	'min' 	=> 200,
			    	'max' 	=> 5000,
			    	'step' 	=> 10,
			    	'default' 	=> 1000,
			]
		);
		$this->add_control(
			'intech_slide_nav',
			[
			    'label'         => esc_html__( 'Enable Nav ', 'intechcore' ),
			    'type'          => Controls_Manager::SWITCHER,
			    'label_on'      => esc_html__( 'On', 'intechcore' ),
			    'label_off'     => esc_html__( 'Off', 'intechcore' ),
			    'return_value'  => 'yes',
			    'default'       => 'yes',
			    'condition' 	=> [
                        	'intech_slider_slide_on' => 'yes',
                  	]
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_slide_box_style',
			[
				'label' => esc_html__( 'Box', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'intech_slide_overly',
				'label' => __( 'Background', 'intechcore' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .intech-slide-item:before',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'intech_slide_title_style',
			[
				'label' => esc_html__( 'Title', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'intech_slide_title_font',
				'label' => esc_html__( 'Typography', 'intechcore' ),
				'selector' => '{{WRAPPER}} .intech-slider-hadding h2',
			]
		); 
		$this->add_responsive_control(
			'intech_slide_title_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slider-hadding h2' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
		'intech_slide_title_margin',
			[
				'label' => __( 'Margin', 'intechcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .intech-slider-hadding h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'intech_slide_title_padding',
			[
				'label' => __( 'Padding', 'intechcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .intech-slider-hadding h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'subtitle_slider',
			[
				'label' => __( 'Sub Title', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'intech_slide_stitle_font',
				'label' => esc_html__( 'Typography', 'intechcore' ),
				'selector' => '{{WRAPPER}} .intech-slider-stitle span',
			]
		); 
		$this->add_responsive_control(
			'intech_slide_stitle_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slider-stitle span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
		'intech_slide_stitle_margin',
			[
				'label' => __( 'Margin', 'intechcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .intech-slider-stitle span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'intech_slide_stitle_padding',
			[
				'label' => __( 'Padding', 'intechcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .intech-slider-stitle span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'intech_slide_dec_style',
			[
				'label' => esc_html__( 'Content', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'intech_slide_dec_font',
				'label' => esc_html__( 'Typography', 'intechcore' ),
				'selector' => '{{WRAPPER}} .intech-slider-hadding h2',
			]
		); 
		$this->add_responsive_control(
			'intech_slide_dec_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slider-hadding h2' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
		'intech_slide_dec_margin',
			[
				'label' => __( 'Margin', 'intechcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .intech-slider-hadding h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'intech_slide_dec_padding',
			[
				'label' => __( 'Padding', 'intechcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .intech-slider-hadding h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_slide_readmore_style',
			[
				'label' => esc_html__( 'ReadMore Button', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'intech_slide_rbtn_font',
				'label' => esc_html__( 'Typography', 'intechcore' ),
				'selector' => '{{WRAPPER}} a.theme-button',
			]
		); 
		$this->add_responsive_control(
		'intech_slide_rbtn_margin',
			[
				'label' => __( 'Margin', 'intechcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} a.theme-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'intech_slide_rbtn_padding',
			[
				'label' => __( 'Padding', 'intechcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} a.theme-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->start_controls_tabs(
			'intech_rbtn_tabs'
		);

		$this->start_controls_tab(
			'intech_rbtn_tab_n',
			[
				'label' => __( 'Normal', 'intechcore' ),
			]
		);
		$this->add_responsive_control(
			'intech_slide_rbtn_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.theme-button' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'intech_slide_rbtn_bg',
				'label' => __( 'Background', 'intechcore' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} a.theme-button',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'intech_slide_rbtn_shadow',
				'label' => __( 'Button Shadow', 'intechcore' ),
				'selector' => '{{WRAPPER}} a.theme-button',
			]
		);
		$this->add_control(
			'intech_slide_rbtn_radius',
			[
				'label' => __( 'Radius', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} a.theme-button' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'intech_rbtn_tab_h',
			[
				'label' => __( 'Hover', 'intechcore' ),
			]
		);
		$this->add_responsive_control(
			'intech_slide_rbtnh_color',
			[
				'label' => esc_html__( 'Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.theme-button:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'intech_slide_rbtnh_bg',
				'label' => __( 'Background', 'intechcore' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} a.theme-button:hover',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'intech_slide_rbtnh_shadow',
				'label' => __( 'Button Shadow', 'intechcore' ),
				'selector' => '{{WRAPPER}} a.theme-button:hover',
			]
		);
		$this->add_control(
			'intech_slide_rbtnh_radius',
			[
				'label' => __( 'Radius', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} a.theme-button:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_slide_video_btn_style',
			[
				'label' => esc_html__( 'Video Button', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'intech_slide_vbtn_color',
			[
				'label' => esc_html__( 'Normal Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slide-button.intech-slide-video a i:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'intech_slide_vbtnh_color',
			[
				'label' => esc_html__( 'Hover Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slide-button.intech-slide-video a:hover i:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'intech_slide_vbtnt_color',
			[
				'label' => esc_html__( 'Text Normal Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slide-button.intech-slide-video a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'intech_slide_vbtnht_color',
			[
				'label' => esc_html__( 'Text Hover Color', 'intechcore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slide-button.intech-slide-video a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'intech_slide_arrow_btn_style',
			[
				'label' => esc_html__( 'Arrow Icon', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'restly_slider_arrow_tabs'
		);
		$this->start_controls_tab(
			'restly_slider_arrow_tabs_normal',
			[
				'label' => __( 'Normal', 'restlycore' ),
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrow_size',
			[
				'label' => esc_html__( 'Icon SIze', 'restlycore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .intech-slide button.slick-prev.slick-arrow:before,.intech-slide button.slick-next.slick-arrow:before' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrow_color',
			[
				'label' => esc_html__( 'Color', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slide button.slick-prev.slick-arrow:before,.intech-slide button.slick-next.slick-arrow:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrows_bcolor',
			[
				'label' => esc_html__( 'Background Color', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .intech-slide button.slick-prev.slick-arrow,.intech-slide button.slick-next.slick-arrow' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrow_widht',
			[
				'label' => esc_html__( 'Width', 'restlycore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 30,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 60,
				],
				'selectors' => [
					'{{WRAPPER}} button.slick-arrow' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrow_height',
			[
				'label' => esc_html__( 'Height', 'restlycore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 30,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} button.slick-arrow' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrow_radius',
			[
				'label' => esc_html__( 'Radius', 'restlycore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} button.slick-arrow' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'restly_slider_arrow_tabs_hover',
			[
				'label' => __( 'Hover', 'restlycore' ),
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrow_hcolor',
			[
				'label' => esc_html__( 'Color', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.slick-prev.slick-arrow:hover:before, button.slick-next.slick-arrow:hover:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrows_hbcolor',
			[
				'label' => esc_html__( 'Background Color', 'restlycore' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} button.slick-prev.slick-arrow:hover, button.slick-next.slick-arrow:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'restly_slider_arrow_hradius',
			[
				'label' => esc_html__( 'Radius', 'restlycore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} button.slick-arrow:hover' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();


	}

	/**
	 * Render progress widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        	$dynamic_num = rand(35245545, 541541745);
        	if($settings['intech_slider_slide_on'] == 'yes' ){
				if($settings['intech_slide_aloop'] == 'yes' ){
					$aplay = 'true';
					}else{
					$aplay = 'false';
				}
				if($settings['intech_slide_nav'] == 'yes' ){
				$nav = 'true';
				}else{
				$nav = 'false';
				}
            echo '
			<script>
			jQuery(document).ready(function($) {
				"use strict";
				$(".slider-'.esc_attr($dynamic_num).'").slick({
					autoplay:'.esc_attr($aplay).',
					arrows:'.esc_attr($nav).',
					slidesToShow:1,
					slidesToScroll:1,';
                  if(!empty($settings['intech_slide_aspeed'])){
                        echo 'autoplaySpeed:'.esc_attr($settings['intech_slide_aspeed']).',';
                    }
                    if(!empty($settings['intech_slide_speed'])){
                        echo 'speed:'.esc_attr($settings['intech_slide_speed']).',';
                    }
            	echo '
				});
				$(".slider-popUp").videoPopup( {
				    autoplay: 1, controlsColor: "white", 
				    showVideoInformations: 0, 
				    width: 1000, 
				    customOptions: {
					  rel: 0, 
					  end: 60
				    }
				});
			});
			</script>';
		 }
		
		?>
		<div class="intech-sliders">
			<div class="intech-slide slider-<?php echo esc_attr($dynamic_num); ?>">
				<?php foreach ($settings['intech_sliders'] as $intech_slider) : 
					if($intech_slider['intech_slider_btns'] == 'page' ){
						$link = get_page_link( $intech_slider['intech_slider_page_link'] );
					}else{
						$link = $intech_slider['intech_slider_extral'];
					}
				?> 
				<div class="intech-slide-item" style="background-image:url( <?php echo esc_url(wp_get_attachment_image_url( $intech_slider['intech_slider_image']['id'], 'full' )); ?> )">
		 			<div class="intech-slider-table">
		 				<div class="intech-slider-table-call">
		 					<div class="container">
								<div class="row">
									<div class="col-12 col-sm-10 col-md-8 col-lg-8">
										<div class="intech-slide-content">
											<?php if(!empty($intech_slider['intech_slider_stitle'])) : ?>
											<div class="intech-slider-stitle">
												<span><?php echo esc_html($intech_slider['intech_slider_stitle']); ?></span>
											</div>
											<?php endif; ?>
											<div class="intech-slider-hadding">
												<?php echo wp_kses_post(wpautop($intech_slider['intech_slider_title'])); ?>
											</div>
											<div class="intech-sldie-dec">
												<?php echo wp_kses_post(wpautop($intech_slider['intech_slider_content'])); ?>
											</div>
											<div class="intech-slide-buttons">
												<?php if(!empty($intech_slider['intech_slider_btn_enable'] == 'yes' )) : ?>
												<div class="intech-slide-button">
													<a href="<?php echo esc_url($link); ?>" class="theme-button colorbg">
														<?php echo esc_html($intech_slider['intech_slider_btn_text']); ?><i class="flaticon-right-arrow"></i></a>
												</div>
												<?php endif; ?>
												<?php if(!empty($intech_slider['intech_slider_bideo_enable'] == 'yes' )) : ?>
												<div class="intech-slide-button intech-slide-video">
													<a href="#" data-video-url="<?php echo esc_url($intech_slider['intech_slider_video_link']); ?>" class="slider-popUp"><i class="flaticon-play-button-1"></i> <?php echo esc_html($intech_slider['intech_slider_video_text']) ?></a>
												</div>
												<?php endif; ?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_slider_Widget );