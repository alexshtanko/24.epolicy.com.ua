<?php 
if(!function_exists('intech_header_enabled')){
    function intech_header_enabled() {
        $header_id = eduschool_extension::get_settings( 'type_header', '' );
        $status    = false;

        if ( '' !== $header_id ) {
            $status = true;
        }

        return apply_filters( 'intech_header_enabled', $status );
    }
}

if(!function_exists('intech_footer_enabled')){
    function intech_footer_enabled() {
        $header_id = eduschool_extension::get_settings( 'type_footer', '' );
        $status    = false;

        if ( '' !== $header_id ) {
            $status = true;
        }

        return apply_filters( 'intech_footer_enabled', $status );
    }
}

if(!function_exists('get_header_content')){
    function get_header_content() {
        $intech_get_header_id = eduschool_extension::intech_get_header_id();
        $frontend = new \Elementor\Frontend;
        echo $frontend->get_builder_content_for_display($intech_get_header_id);
    }
}


add_filter( 'woocommerce_add_to_cart_fragments', 'intech_mini_add_to_cart_fragment' );
function intech_mini_add_to_cart_fragment( $fragments ) { 
    if ( class_exists( 'woocommerce' ) ) {
        if (!function_exists('intech_header_add_to_cart_fragment')) {
            $product_id = (int) apply_filters('woocommerce_add_to_cart_product_id', $_POST['product_id']);
            $fragments['added_product'] = get_post($product_id)->post_title;
            ob_start();
            $count = WC()->cart->get_cart_contents_count();
            ?>
            <?php if ( $count > 0 ): ?>
                <span class="cart-contents-count"><?php echo esc_attr( $count ); ?></span>
            <?php else: ?>
                <span class="cart-contents-count">0</span>
            <?php endif; ?>            
            <?php
            $fragments['.wrap-count-content .cart-contents-count'] = ob_get_clean();
            ob_end_clean();
            return $fragments;
        }
    }
}