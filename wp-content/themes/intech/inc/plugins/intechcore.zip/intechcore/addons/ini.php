<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
final class eduschool_extension {
	const VERSION = '1.0.0';

	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	const MINIMUM_PHP_VERSION = '7.0';

	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	public function __construct() {

		add_action( 'init', [ $this, 'i18n' ] );
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}
	public function i18n() {
		load_plugin_textdomain( 'intechcore' );
	}
	public function init() {
		require_once( __DIR__ . '/control/check-notice.php' );
		require_once( __DIR__ . '/control/css-load.php' );
		require_once( __DIR__ . '/header-footer/intech-function.php' );
        add_action( 'init', [ $this, 'intech_header_footer_post_type' ] );
        add_action( 'add_meta_boxes', [ $this, 'intech_header_footer_register_metabox' ] );
        add_action( 'save_post', [ $this, 'intech_header_footer_save_meta' ] );
        add_filter( 'single_template', [ $this, 'intech_header_footer_load_canvas_template' ] );
        add_action( 'wp', [ $this, 'hooks' ],100 );
	}
	public function admin_notice_missing_main_plugin() {
		require_once( __DIR__ . '/control/messing-notice.php' );
	}
	public function admin_notice_minimum_elementor_version() {
		require_once( __DIR__ . '/control/mimv-notice.php' );
	}
	public function admin_notice_minimum_php_version() {
		require_once( __DIR__ . '/control/mimvp-notice.php' );
	}
	public function init_widgets() {
		// Include Widget files
		require_once( __DIR__ . '/widgets/intech-clients.php' );
		require_once( __DIR__ . '/widgets/intech-about.php' );
		require_once( __DIR__ . '/widgets/intech-about-video.php' );
		require_once( __DIR__ . '/widgets/intech-title.php' );
		require_once( __DIR__ . '/widgets/intech-service.php' );
		require_once( __DIR__ . '/widgets/intech-progress.php' );
		require_once( __DIR__ . '/widgets/intech-pricing.php' );
		require_once( __DIR__ . '/widgets/intech-contact-box.php' );
		require_once( __DIR__ . '/widgets/intech-project.php' );
		require_once( __DIR__ . '/widgets/intech-buttons.php' );
		require_once( __DIR__ . '/widgets/intech-team.php' );
		require_once( __DIR__ . '/widgets/intech-testimonial.php' );
		require_once( __DIR__ . '/widgets/intech-blog.php' );
		require_once( __DIR__ . '/widgets/intech-contact-message.php' );
		require_once( __DIR__ . '/widgets/intech-counter.php' );
		require_once( __DIR__ . '/widgets/intech-support.php' );
		require_once( __DIR__ . '/widgets/intech-promo-content.php' );
		require_once( __DIR__ . '/widgets/intech-contact-info.php' );
		require_once( __DIR__ . '/widgets/intech-slider.php' );
		require_once( __DIR__ . '/widgets/intech-shape.php' );
		require_once( __DIR__ . '/widgets/dot-shape.php' );
		require_once( __DIR__ . '/widgets/mailchip-subscribe.php' );
		require_once( __DIR__ . '/widgets/counter-2.php' );
		require_once( __DIR__ . '/widgets/iconbox.php' );
		require_once( __DIR__ . '/widgets/intech-navmenu.php' );
		require_once( __DIR__ . '/widgets/intech-search.php' );
		require_once( __DIR__ . '/widgets/intech-social.php' );
		require_once( __DIR__ . '/widgets/intech-mini-cart.php' );
		
		// Register widget

	}
	public function widget_styles() {
		require_once( __DIR__ . '/control/intech-widget-style.php' );
	}

    static function intech_get_template_elementor($type = null) {
        $args = [
            'post_type' => 'elementor_library',
            'posts_per_page' => -1,
        ];
        if ($type) {
            $args['tax_query'] = [
                [
                    'taxonomy' => 'elementor_library_type',
                    'field' => 'slug',
                    'terms' => $type,
                ],
            ];
        }
        $template = get_posts($args);
        $tpl = array();
        if (!empty($template) && !is_wp_error($template)) {
            foreach ($template as $post) {
                $tpl[$post->ID] = $post->post_title;
            }
        }
        return $tpl;
    }

    /* Post type header footer */
    public function intech_header_footer_post_type() {
        $labels = array(
            'name'                  => esc_html__( 'Intech Header - Footer', 'intechcore' ),
            'singular_name'         => esc_html__( 'intech Header - Footer', 'intechcore' ),
            'rewrite'               => array( 'slug' => esc_html__( 'intech Header - Footer' ) ),
            'menu_name'             => esc_html__( 'intech Header - Footer', 'intechcore' ),
            'add_new'               => esc_html__( 'Add New', 'intechcore' ),
            'add_new_item'          => esc_html__( 'Add New Template', 'intechcore' ),
            'new_item'              => esc_html__( 'New Template Item', 'intechcore' ),
            'edit_item'             => esc_html__( 'Edit Template Item', 'intechcore' ),
            'view_item'             => esc_html__( 'View Template', 'intechcore' ),
            'all_items'             => esc_html__( 'All Template', 'intechcore' ),
            'search_items'          => esc_html__( 'Search Template', 'intechcore' ),
            'not_found'             => esc_html__( 'No Template Items Found', 'intechcore' ),
            'not_found_in_trash'    => esc_html__( 'No Template Items Found In Trash', 'intechcore' ),
            'parent_item_colon'     => esc_html__( 'Parent Template:', 'intechcore' ),
            'not_found'             => esc_html__( 'No Template found', 'intechcore' ),
            'not_found_in_trash'    => esc_html__( 'No Template found in Trash', 'intechcore' )

        );
        $args = array(
            'labels'      => $labels,
            'supports'    => array( 'title', 'thumbnail', 'elementor' ),
            'public'      => true,
            'has_archive' => true,
            'rewrite'     => array('slug' => get_theme_mod('intech_header_footer_slug','intech_header_footer')),
            'menu_icon'   => 'dashicons-admin-page',
        );
        register_post_type( 'intech_header_footer', $args );

        flush_rewrite_rules();
    }

    public function intech_header_footer_register_metabox() {
        add_meta_box(
            'intechhf-meta-box',
            esc_html__( 'intech Header Or Footer Options', 'intechcore' ), 
            [ $this, 'intech_header_footer_metabox_render'], 
            'intech_header_footer', 'normal', 'high' );
    }  

    public function intech_header_footer_metabox_render( $post ) {
        $values            = get_post_custom( $post->ID );
        $template_type     = isset( $values['intech_template_type'] ) ? esc_attr( $values['intech_template_type'][0] ) : '';
        ?>
        <table class="intech-options-table widefat">
            <tbody>
                <tr class="intech-options-row type-of-template">
                    <td class="intech-options-row-heading">
                        <label for="intech_template_type"><?php esc_html_e( 'Type of Template', 'intechcore' ); ?></label>
                    </td>
                    <td class="intech-options-row-content">
                        <select name="intech_template_type" id="intech_template_type">
                            <option value="" <?php selected( $template_type, '' ); ?>><?php esc_html_e( 'Select Option', 'intechcore' ); ?></option>
                            <option value="type_header" <?php selected( $template_type, 'type_header' ); ?>><?php esc_html_e( 'Header', 'intechcore' ); ?></option>
                            <option value="type_footer" <?php selected( $template_type, 'type_footer' ); ?>><?php esc_html_e( 'Footer', 'intechcore' ); ?></option>
                        </select>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php 
    }

    public function intech_header_footer_save_meta( $post_id ) {

        if ( isset( $_POST['intech_template_type'] ) ) {
            update_post_meta( $post_id, 'intech_template_type', esc_attr( $_POST['intech_template_type'] ) );
        }

        return false;
    }

    public function intech_header_footer_load_canvas_template( $single_template ) {
        global $post;

        if ( 'intech_header_footer' == $post->post_type ) {
            $elementor_canvas = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

            if ( file_exists( $elementor_canvas ) ) {
                return $elementor_canvas;
            } else {
                return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
            }
        }

        return $single_template;
    }    

    public static function intech_get_header_id() {
        $header_id = self::get_template_id( 'type_header' );

        if ( '' === $header_id ) {
            $header_id = false;
        }

        return apply_filters( 'intech_get_header_id', $header_id );
    }

    public static function intech_get_footer_id() {
        $footer_id = self::get_template_id( 'type_footer' );

        if ( '' === $footer_id ) {
            $footer_id = false;
        }

        return apply_filters( 'intech_get_footer_id', $footer_id );
    }

    public static function get_template_id( $type ) {

        $args = [
            'post_type' => 'intech_header_footer',
            'posts_per_page' => -1,
        ];
        $intechhf_templates = get_posts($args);

        foreach ( $intechhf_templates as $template ) {
            if ( get_post_meta( absint( $template->ID ), 'intech_template_type', true ) === $type ) {
                return $template->ID;
            }
        }

        return '';
        
    }

    public static function get_settings( $setting = '', $default = '' ) {
        if ( 'type_header' == $setting || 'type_footer' == $setting ) {
            $templates = self::get_template_id( $setting );
            $template = ! is_array( $templates ) ? $templates : $templates[0];
            return $template;
        }
    }

    public function hooks() {
        if ( intech_header_enabled() ) { 
            add_action( 'get_header', [ $this, 'intech_override_header' ] ); 
            add_action( 'intech_header', [ $this, 'intech_render_header' ] );             
        }

        if ( intech_footer_enabled() ) {
            add_action( 'get_footer', [ $this, 'intech_override_footer' ] ); 
            add_action( 'intech_footer', [ $this, 'intech_render_footer' ] ); 
        }
    }  

    public function intech_override_header() {
		require_once( __DIR__ . '/header-footer/intech-header.php' );
        $templates   = [];
        $templates[] = 'header.php';
        remove_all_actions( 'wp_head' );
        ob_start();
        locate_template( $templates, true );
        ob_get_clean();
    }

    public function intech_override_footer() {
		require_once( __DIR__ . '/header-footer/intech-footer.php' );
        $templates   = [];
        $templates[] = 'footer.php';
        remove_all_actions( 'wp_footer' );
        ob_start();
        locate_template( $templates, true );
        ob_get_clean();
    }

    public static function get_header_content() {
        $intech_get_header_id = self::intech_get_header_id();
        $frontend = new \Elementor\Frontend;
        echo $frontend->get_builder_content_for_display($intech_get_header_id);
    }

    public static function get_footer_content() {
        $intech_get_footer_id = self::intech_get_footer_id();
        $frontend = new \Elementor\Frontend;
        echo $frontend->get_builder_content_for_display($intech_get_footer_id);
    }

    public function intech_render_header() {
        ?>        
        <header class="site-header intech-custom-header" role="banner"> 
            <div class="intech-container"> 
                <div class="intech-row">
                    <div class="intech-col">              
                    <?php echo self::get_header_content(); ?>
                    </div>
                </div>
            </div>
        </header>
        <?php
    }

    public function intech_render_footer() {
        ?>
        <footer class="site-footer intech-custom-footer" role="contentinfo">
            <div class="intech-container"> 
                <div class="intech-row">
                    <div class="intech-col">                
                    <?php echo self::get_footer_content(); ?>
                    </div>
                </div>
            </div>
        </footer>
        <?php
    }

    public function intech_set_columns_status($columns) {

        $date_column = $columns['date'];
        $author_column = $columns['author'];

        unset( $columns['date'] );

        $columns['status'] = esc_html__( 'Status', 'intechcore' );
        $columns['date']      = $date_column;

        return $columns;
    }

    public function intech_render_column_status($column, $post_id) {  
        if ( is_admin() ){
            $curent_header = $this->intech_get_header_id();
            $curent_footer = $this->intech_get_footer_id();
            $type = get_post_meta( $post_id, 'intech_template_type', true );
            if ($type == 'type_header') {
                if ($post_id == $curent_header ) {
                    echo ( '<span class="intech-header-footer-status intech-header-footer-status-on">'. esc_html__('On', 'intechcore') .'</span>' );
                } else {
                    echo ( '<span class="intech-header-footer-status intech-header-footer-status-off">'. esc_html__('Off', 'intechcore') .'</span>' );
                }
                
            } elseif($type == 'type_footer') {
                if ($post_id == $curent_footer ) {
                    echo ( '<span class="intech-header-footer-status intech-header-footer-status-on">'. esc_html__('On', 'intechcore') .'</span>' );
                } else {
                    echo ( '<span class="intech-header-footer-status intech-header-footer-status-off">'. esc_html__('Off', 'intechcore') .'</span>' );
                }
            }else {
                echo ( '<span class="intech-header-footer-status intech-header-footer-status-off">'. esc_html__('Off', 'intechcore') .'</span>' );
            }
            
        }
    } 
        

}
eduschool_extension::instance();