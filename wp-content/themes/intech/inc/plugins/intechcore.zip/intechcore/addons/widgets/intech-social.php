<?php namespace Elementor;

class intech_socials_Widget extends Widget_Base {

    public function get_name() {

        return 'intech_socials';
    }

    public function get_title() {
        return esc_html__( 'Intech Social', 'intechcore' );
    }

    public function get_icon() {

        return 'eicon-social-icons';
    }

    public function get_categories() {
        return ['intechhf'];
    }

    protected function _register_controls() {

        //Content tab start
        $this->start_controls_section(
            'intech_socials_options',
            [
                'label' => esc_html__( 'Intech Social', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();
       
        $repeater->add_control(
            'intech_social_icon',
            [
                'label' => esc_html__( 'Icon', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );
        $repeater->add_control(
            'intech_social_link',
            [
                'label' => __( 'Link', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'intechcore' ),
                'show_external' => true,
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ]
        );
        $repeater->add_responsive_control(
            'intech_social_color',
            [
                'label' => esc_html__( 'Icon Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
            ]
        );
        $repeater->add_responsive_control(
            'intech_social_bgc',
            [
                'label' => esc_html__( 'Icon BG Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
            ]
        );
        $this->add_control(
            'intech_socials',
            [
                'label' => esc_html__( 'Icon List', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'intech_social_icon' => '',
                        'intech_social_link' => '',
                        'intech_social_color' => '',
                        'intech_social_bgc' => '',
                    ],
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_social_box_alinghe',
            [
                'label' => __( 'Alignment', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'intechcore' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'intechcore' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'intechcore' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .intech-social-wrapper' => 'text-align: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
			'intech_social_icon_css',
			[
				'label' => esc_html__( 'Social Icon', 'intechcore' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        $this->add_responsive_control(
            'intech_social_icon_size',
            [
                'label' => esc_html__( 'Icon Size', 'restlycore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 14,
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-social-wrapper ul li a' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_social_icon_width',
            [
                'label' => esc_html__( 'Width', 'restlycore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 35,
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-social-wrapper ul li a' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_social_icon_heiht',
            [
                'label' => esc_html__( 'Height', 'restlycore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 35,
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-social-wrapper ul li a' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_social_icon_lheiht',
            [
                'label' => esc_html__( 'Line Height', 'restlycore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 35,
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-social-wrapper ul li a' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_social_icon_radisu',
            [
                'label' => esc_html__( 'Border Raidus', 'restlycore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ '%' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-social-wrapper ul li a' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_social_icon_margin',
            [
                'label' => esc_html__( 'Margin', 'restlycore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default' => [
                    'top' => '0',
                    'right' => '10',
                    'bottom' => '0',
                    'left' => '0',
                    'isLinked' => true
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-social-wrapper ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
        
    }
    //Render
    protected function render() {
        $settings = $this->get_settings_for_display();

        ob_start();
        ?>
        <div class="intech-social-wrapper">
            <ul>
            <?php foreach( $settings['intech_socials'] as $social ){
                $target = $social['intech_social_link']['is_external'] ? ' target="_blank"' : '';
                $nofollow = $social['intech_social_link']['nofollow'] ? ' rel="nofollow"' : '';
                echo '<li><a href="' . $social['intech_social_link']['url'] . '"' . $target . $nofollow . ' class="'.$social['intech_social_icon']['value'].'" style="background-color:'.$social['intech_social_bgc'].'; color:'.$social['intech_social_color'].'"></a></li>';
            } ?>
            </ul>
        </div>
        <?php
        echo ob_get_clean();

    }
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_socials_Widget );