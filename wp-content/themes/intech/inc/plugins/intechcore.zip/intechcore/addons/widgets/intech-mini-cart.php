<?php namespace Elementor;

class intech_mini_cart_Widget extends Widget_Base {

    public function get_name() {

        return 'intech_minicart';
    }

    public function get_title() {
        return esc_html__( 'Intech Mini Cart', 'intechcore' );
    }

    public function get_icon() {

        return 'eicon-cart';
    }

    public function get_categories() {
        return ['intechhf'];
    }

    protected function _register_controls() {

        //Content tab start
        $this->start_controls_section(
            'intech_minicart_options',
            [
                'label' => esc_html__( 'intech Mini Cart', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'intech_minicart_icon_tabs'
        );
        $this->start_controls_tab(
            'intech_minicart_icon_tabs_normal',
            [
                'label' => __( 'Normal', 'intechcore' ),
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_icon_color',
            [
                'label' => esc_html__( 'icon Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-hmini a.cart-contents' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_icon_icon_size',
            [
                'label' => esc_html__( 'Icon Size', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-hmini a.cart-contents' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_label_color',
            [
                'label' => esc_html__( 'Label Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} ul.intech-hmini span.count' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_label_bgcolor',
            [
                'label' => esc_html__( 'Label Background Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} ul.intech-hmini span.count' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_icon_margin',
            [
                'label' => esc_html__( 'Margin', 'intechcore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '22',
                    'isLinked' => true
                    ],
                'selectors' => [
                    '{{WRAPPER}} ul.intech-hmini' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_icon_padding',
            [
                'label' => esc_html__( 'Padding', 'intechcore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} ul.intech-hmini' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'intech_minicart_icon_tabs_hover',
            [
                'label' => __( 'Hover', 'intechcore' ),
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_icon_hcolor',
            [
                'label' => esc_html__( 'icon Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-hmini a.cart-contents:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
        $this->start_controls_section(
            'intech_minicart_item_options',
            [
                'label' => esc_html__( 'intech Mini Cart Item', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'intech_minicart_items_tabs'
        );
        $this->start_controls_tab(
            'intech_minicart_items_tabs_title',
            [
                'label' => __( 'Title', 'intechcore' ),
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'intech_minicart_items_typo',
                'label' => esc_html__( 'Typography', 'intechcore' ),
                'selector' => '{{WRAPPER}} li.intech-mini-cart-items li.woocommerce-mini-cart-item.mini_cart_item a',
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_items_color',
            [
                'label' => esc_html__( 'Title Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} li.intech-mini-cart-items li.woocommerce-mini-cart-item.mini_cart_item a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_items_hcolor',
            [
                'label' => esc_html__( 'Title Hover Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} li.intech-mini-cart-items li.woocommerce-mini-cart-item.mini_cart_item a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'intech_miniamount',
            [
                'label' => __( 'Amount Section', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'intech_minicart_items_price_typo',
                'label' => esc_html__( 'Price Typography', 'intechcore' ),
                'selector' => '{{WRAPPER}} .intech-mini-cart-items span.quantity',
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_items_price_color',
            [
                'label' => esc_html__( 'Price Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-mini-cart-items span.quantity' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'intech_minicart_items_tabs_subtitle',
            [
                'label' => __( 'Sub Title', 'intechcore' ),
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_stitle_color',
            [
                'label' => esc_html__( 'Sub Title Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .woocommerce .widget_shopping_cart .total strong, .woocommerce.widget_shopping_cart .total strong' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'intech_minicart_sub_title_typo',
                'label' => esc_html__( 'Sub Title Typography', 'intechcore' ),
                'selector' => '{{WRAPPER}} .woocommerce .widget_shopping_cart .total strong, .woocommerce.widget_shopping_cart .total strong',
            ]
        );
        $this->add_control(
            'intech_minitotlaamount',
            [
                'label' => __( 'Total Amount', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_total_color',
            [
                'label' => esc_html__( 'Total Amout Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-mini-cart-items .woocommerce-mini-cart__total.total span.woocommerce-Price-amount.amount' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'intech_minicart_totla_typo',
                'label' => esc_html__( 'Total Amout Typography', 'intechcore' ),
                'selector' => '{{WRAPPER}} .intech-mini-cart-items .woocommerce-mini-cart__total.total span.woocommerce-Price-amount.amount',
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'intech_minicart_btn1_tabs',
            [
                'label' => __( 'Buttons', 'intechcore' ),
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'intech_minicart_btn1_typo',
                'label' => esc_html__( 'Typography', 'intechcore' ),
                'selector' => '{{WRAPPER}} .intech-mini-cart-items p.woocommerce-mini-cart__buttons.buttons a.button.wc-forward',
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_btn1_color',
            [
                'label' => esc_html__( 'Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-mini-cart-items p.woocommerce-mini-cart__buttons.buttons a.button.wc-forward' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_btn1_hcolor',
            [
                'label' => esc_html__( 'Hover Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-mini-cart-items p.woocommerce-mini-cart__buttons.buttons a.button.wc-forward:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_btn1_bg',
            [
                'label' => esc_html__( 'Background Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-mini-cart-items p.woocommerce-mini-cart__buttons.buttons a.button.wc-forward' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_btn1_hbg',
            [
                'label' => esc_html__( 'Hover Background Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-mini-cart-items p.woocommerce-mini-cart__buttons.buttons a.button.wc-forward:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_btn1_margin',
            [
                'label' => esc_html__( 'Margin', 'intechcore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .intech-mini-cart-items p.woocommerce-mini-cart__buttons.buttons a.button.wc-forward' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_minicart_btn1_padding',
            [
                'label' => esc_html__( 'Padding', 'intechcore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .intech-mini-cart-items p.woocommerce-mini-cart__buttons.buttons a.button.wc-forward' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
        
    }
    //Render
    protected function render() {
        $settings = $this->get_settings_for_display();

        ob_start();
        if ( class_exists( 'WooCommerce' ) ) {
                intech_woocommerce_header_cart();
        }
        echo ob_get_clean();

    }
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_mini_cart_Widget );