<?php
namespace Elementor;

class intech_dot_shape_Widget extends Widget_Base {

    public function get_name() {

        return 'intech_dot_shape';
    }

    public function get_title() {
        return esc_html__( 'intech Dot Shape', 'intechcore' );
    }

    public function get_icon() {

        return 'eicon-apps';
    }

    public function get_categories() {
        return ['intechcore'];
    }

    protected function _register_controls() {

        //Content tab start
        $this->start_controls_section(
            'intech_dots_shape_options',
            [
                'label' => esc_html__( 'Animation', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'intech_dots_animation_enable',
            [
                'label'     => esc_html__( 'Enable Animation', 'intechcore' ),
                'type'      => \Elementor\Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Show', 'intechcore' ),
                'label_off' => esc_html__( 'Hide', 'intechcore' ),
            ]
        );
        $this->add_control(
            'intech_dots_shape_select',
            [
                'label'     => esc_html__( 'Select Animation', 'intechcore' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'shapeMover',
                'options'   => [
                    'shapeMover'        => esc_html__( 'Shape Mover', 'intechcore' ),
                    'bubbleMover'       => esc_html__( 'Bubble Mover', 'intechcore' ),
                    'bounce'            => esc_html__( 'Bounce', 'intechcore' ),
                    'zoomIn'            => esc_html__( 'ZoomIn', 'intechcore' ),
                    'flash'             => esc_html__( 'Flash', 'intechcore' ),
                    'pulse'             => esc_html__( 'Pulse', 'intechcore' ),
                    'rubberBand'        => esc_html__( 'Rubber Band', 'intechcore' ),
                    'shake'             => esc_html__( 'ShakeX', 'intechcore' ),
                    'fadeIn'            => esc_html__( 'FadeIn', 'intechcore' ),
                    'fadeInDown'        => esc_html__( 'FadeIn Down', 'intechcore' ),
                    'fadeInLeft'        => esc_html__( 'FadeIn Left', 'intechcore' ),
                    'fadeInRight'       => esc_html__( 'FadeIn Right', 'intechcore' ),
                    'fadeInUp'          => esc_html__( 'FadeIn Up', 'intechcore' ),
                    'fadeOut'           => esc_html__( 'FadeOut', 'intechcore' ),
                    'fadeOutDown'       => esc_html__( 'FadeOut Down', 'intechcore' ),
                    'fadeOutLeft'       => esc_html__( 'FadeOut Left', 'intechcore' ),
                    'fadeOutRight'      => esc_html__( 'FadeOut Right', 'intechcore' ),
                    'fadeOutUp'         => esc_html__( 'FadeOut Up', 'intechcore' ),
                    'flip'              => esc_html__( 'Flip', 'intechcore' ),
                    'flipInX'           => esc_html__( 'FlipInX', 'intechcore' ),
                    'flipInY'           => esc_html__( 'FlipInY', 'intechcore' ),
                    'rotateIn'          => esc_html__( 'RotateIn', 'intechcore' ),
                    'rotateInDownLeft'  => esc_html__( 'RotateIn Down Left', 'intechcore' ),
                    'rotateInDownRight' => esc_html__( 'RotateIn Down Right', 'intechcore' ),
                    'rotateInUpLeft'    => esc_html__( 'RotateIn Up Left', 'intechcore' ),
                    'rotateInUpRight'   => esc_html__( 'RotateIn Up Right', 'intechcore' ),
                    'rotateOut'         => esc_html__( 'Rotate Out', 'intechcore' ),
                    'hinge'             => esc_html__( 'Hinge', 'intechcore' ),
                    'slideInDown'       => esc_html__( 'SlideIn Down', 'intechcore' ),
                    'slideInLeft'       => esc_html__( 'SlideIn Left', 'intechcore' ),
                    'slideInRight'      => esc_html__( 'SlideIn Right', 'intechcore' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .shapeanimation' => 'animation-name: {{VALUE}};',
                ],
                'condition' => [
                    'intech_dots_animation_enable' => 'yes',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_dots_shape_duration',
            [
                'label'      => esc_html__( 'Animation Duration', 'intechcore' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['s'],
                'range'      => [
                    's' => [
                        'min'  => 0.1,
                        'max'  => 100,
                        'step' => 0.1,
                    ],
                ],
                'default'    => [
                    'unit' => 's',
                    'size' => 9,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .shapeanimation' => '-webkit-animation-duration: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .shapeanimation' => 'animation-duration: {{SIZE}}{{UNIT}};',
                ],
                'condition'  => [
                    'intech_dots_animation_enable' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'intech_dot_shape_CSS',
            [
                'label' => esc_html__( 'Dot Shape', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'intech_dot_shape_width',
            [
                'label'      => esc_html__( 'Width', 'intechcore' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['em', 'px'],
                'range'      => [
                    'em' => [
                        'min'  => 2,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    'px' => [
                        'min'  => 10,
                        'max'  => 800,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'em',
                    'size' => 20,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .dot-shapes' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_dot_shape_height',
            [
                'label'      => esc_html__( 'Height', 'intechcore' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['em', 'px'],
                'range'      => [
                    'em' => [
                        'min'  => 2,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    'px' => [
                        'min'  => 10,
                        'max'  => 800,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'em',
                    'size' => 20,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .dot-shapes' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_dot_shape_top',
            [
                'label'      => esc_html__( 'Position Top To Bottom', 'intechcore' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -1000,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .dot-shapes.shape_dots' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_dot_shape_left',
            [
                'label'      => esc_html__( 'Position Left To Right', 'intechcore' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -1000,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .dot-shapes.shape_dots' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'intech_dot_shape_size',
            [
                'label'      => esc_html__( 'Dot Size', 'intechcore' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 40,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 18,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .dot-shapes.shape_dots' => '-webkit-mask-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_dot_shape_color',
            [
                'label'     => esc_html__( 'Color', 'intechcore' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .dot-shapes.shape_dots' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }
    //Render
    protected function render() {
        $settings = $this->get_settings_for_display();

        ob_start();
        ?>
        <div class="dot-shapes shape_dots dot-animate shapeanimation"></div>
        <?php
echo ob_get_clean();

    }
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_dot_shape_Widget );