<?php do_action( 'intech_footer' ); ?>
<?php wp_footer(); ?>
</body>
</html> 