<?php namespace Elementor;

class intech_subscribe_Widget extends Widget_Base {

    public function get_name() {

        return 'intech_subscribe';
    }

    public function get_title() {
        return esc_html__( 'intech Subscribe', 'intechcore' );
    }

    public function get_icon() {

        return 'eicon-mail';
    }

    public function get_categories() {
        return ['intechcore'];
    }

    protected function _register_controls() {

        //Content tab start
        $this->start_controls_section(
            'intech_subscribe_options',
            [
                'label' => esc_html__( 'intech Subscribe', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_select',
            [
                'label' => esc_html__( 'Select Options', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'one',
                'options' => [
                    'one'  => esc_html__( 'Mailchip Link', 'intechcore' ),
                    'two' => esc_html__( 'Shortcode', 'intechcore' ),
                ],
            ]
        );
        $this->add_control(
            'intech_subscribe_link',
            [
                'label' => esc_html__( 'Link', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( '#', 'intechcore' ),
                'show_label' => true,
                'condition' => [
                    'intech_subscribe_select' => 'one',
                ],
            ]
        );
        $this->add_control(
            'intech_subscribe_shortcode',
            [
                'label' => esc_html__( 'Plugin Shortcode', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( '#', 'intechcore' ),
                'show_label' => true,
                'condition' => [
                    'intech_subscribe_select' => 'two',
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'intech_subscribe_input_CSS_options',
            [
                'label' => esc_html__( 'Input CSS', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_input_CSS_color',
            [
                'label' => esc_html__( 'Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields input[type=email],.intech-subscribe-innter .mc4wp-form-fields input[type=email]::placeholder' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_input_CSS_bg',
            [
                'label' => esc_html__( 'Background Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields input[type=email]' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'label' => esc_html__( 'Shadow', 'restlycore' ),
                'selector' => '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields input[type=email]',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'intech_subscribe_CSS_input_border',
                'label' => esc_html__( 'Border', 'intechcore' ),
                'selector' => '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields input[type=email]',
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_CSS_input_radius',
            [
                'label' => esc_html__( 'Border Radius', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields input[type=email]' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_CSS_input_margin',
            [
                'label' => esc_html__( 'Margin', 'intechcore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields input[type=email]' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_CSS_input_padding',
            [
                'label' => esc_html__( 'Padding', 'intechcore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields input[type=email]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'intech_subscribe_btn_CSS_options',
            [
                'label' => esc_html__( 'Button CSS', 'intechcore' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_btn_CSS_color',
            [
                'label' => esc_html__( 'Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_btn_CSS_hcolor',
            [
                'label' => esc_html__( 'Hover Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_btn_CSS_bg',
            [
                'label' => esc_html__( 'Background Color', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_btn_CSS_hbg',
            [
                'label' => esc_html__( 'Hover Background', 'intechcore' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'intech_subscribe_btn_CSS_typo',
                'label' => esc_html__( 'Typography', 'intechcore' ),
                'selector' => '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'intech_subscribe_btn_CSS_border',
                'label' => esc_html__( 'Border', 'intechcore' ),
                'selector' => '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button',
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_btn_CSS__radius',
            [
                'label' => esc_html__( 'Border Radius', 'intechcore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_btn_CSS_margin',
            [
                'label' => esc_html__( 'Margin', 'intechcore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'intech_subscribe_btn_CSS_padding',
            [
                'label' => esc_html__( 'Padding', 'intechcore' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .intech-subscribe-innter .mc4wp-form-fields button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    //Render
    protected function render() {
        $settings = $this->get_settings_for_display();
        ob_start();
        ?>
        <div class="intech-subscribe-wrapper">
            <div class="intech-subscribe-innter">
            <?php if($settings['intech_subscribe_select'] == 'one' ){
                echo '<form action="'.esc_url($settings['intech_subscribe_link']).'" method="post">
                        <div class="mc4wp-form-fields">
                            <input type="email" name="EMAIL" placeholder="Your email address" required="">
                            <button value="submit">'.esc_html('Subscribe','intechcore').'</button>
                        </div>
                    </form>';
            }else{
                echo do_shortcode($settings['intech_subscribe_shortcode']);
            } ?>
            </div>
        </div>
        <?php
        echo ob_get_clean();

    }
}
Plugin::instance()->widgets_manager->register_widget_type( new intech_subscribe_Widget );