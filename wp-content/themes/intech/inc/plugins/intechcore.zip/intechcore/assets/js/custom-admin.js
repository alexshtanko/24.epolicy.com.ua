(function($) {
    "use strict";
    wp.data.subscribe(() => {
        var postFormat = wp.data.select('core/editor').getEditedPostAttribute('format');
        $('#intech_pfg_meta, #intech_pfv_meta, #intech_pfa_meta').hide();

        if (postFormat == 'gallery') {
            $('#intech_pfg_meta').fadeIn();
        };
        if (postFormat == 'video') {
            $('#intech_pfv_meta').fadeIn();
        };
        if (postFormat == 'audio') {
            $('#intech_pfa_meta').fadeIn();
        };
    });
})(jQuery);