<?php

function intech_post_metabox( $options ) {

    $options[] = array(
        'id'        => 'intech_slider_meta',
        'title'     => esc_html__( 'Slider Options', 'intechcore' ),
        'post_type' => 'slider',
        'context'   => 'normal',
        'priority'  => 'high',
        'sections'  => array(
            array(
                'name'   => 'intech_project_options_meta',
                'title'  => esc_html__( 'Project Option MetaBox', 'intechcore' ),
                'fields' => array(

                    array(
                        'id'       => 'intech_slider_hadding',
                        'type'     => 'wysiwyg',
                        'title'    => esc_html__( 'Slider Big Hadding', 'intechcore' ),
                        'desc'     => esc_html__( 'Please Type Slider Big Hadding', 'intechcore' ),
                        'settings' => array(
                            'media_buttons' => false,
                        ),
                        'default'  => wp_kses(
                            __( '<h1>We do provide creative IT Solution For your Business!</h1>', 'intechcore' ),
                            array(
                                'span'   => array(),
                                'strong' => array(),
                                'h1'     => array(),
                                'h2'     => array(),
                                'h3'     => array(),
                            )
                        ),
                    ),
                    array(
                        'type'    => 'subheading',
                        'content' => esc_html__( 'Buttons One Options', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_slide_button_test',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Button-1 Text', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Button Text', 'intechcore' ),
                        'default' => esc_html__( 'Learn More', 'intechcore' ),
                    ),
                    array(
                        'id'    => 'intech_slide_button_link',
                        'type'  => 'text',
                        'title' => esc_html__( 'Button-1 Link', 'intechcore' ),
                        'desc'  => esc_html__( 'Please Type Button Link Here.', 'intechcore' ),
                    ),
                    array(
                        'type'    => 'subheading',
                        'content' => esc_html__( 'Video Buttons Options', 'intechcore' ),
                    ),
                    array(
                        'id'       => 'intech_slide_button2_test',
                        'type'     => 'wysiwyg',
                        'title'    => esc_html__( 'Video Button Text', 'intechcore' ),
                        'desc'     => esc_html__( 'Please Type Button Text', 'intechcore' ),
                        'settings' => array(
                            'textarea_rows' => 0,
                            'tinymce'       => false,
                            'media_buttons' => false,
                            'quicktags'     => false,
                        ),
                        'default'  => wp_kses(
                            __( 'Play Our New Video', 'intechcore' ),
                            array(
                                'span' => array(),
                            )
                        ),
                    ),
                    array(
                        'id'      => 'intech_slide_button2_link',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Video Link', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Add Youtube or Vimeo Video link.', 'intechcore' ),
                        'default' => esc_html__( 'https://www.youtube.com/watch?v=u8Egk_j0EbY', 'intechcore' ),
                    ),
                ),
            ),
        ),
    );

    $options[] = array(
        'id'        => 'intech_project_meta',
        'title'     => esc_html__( 'Project Options', 'intechcore' ),
        'post_type' => 'project',
        'context'   => 'normal',
        'priority'  => 'high',
        'sections'  => array(
            array(
                'name'   => 'intech_project_options_meta',
                'title'  => esc_html__( 'Project Option MetaBox', 'intechcore' ),
                'fields' => array(
                    array(
                        'id'      => 'intech_pro_title',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Project Title', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Project Title here', 'intechcore' ),
                        'default' => esc_html__( 'Business Agency ', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_pro_client',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Project Client', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Project Client Name here', 'intechcore' ),
                        'default' => esc_html__( 'Mahi Al Rabbi', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_pro_status',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Project Status', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Project Status here', 'intechcore' ),
                        'default' => esc_html__( 'Complete', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_pro_date',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Project Date', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Project Date here', 'intechcore' ),
                        'default' => esc_html__( '05 August 2019', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_pro_value',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Project Value', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Project Status here', 'intechcore' ),
                        'default' => esc_html__( '$500', 'intechcore' ),
                    ),

                    array(
                        'id'      => 'intech_pro_video_link',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Project Project video Link', 'intechcore' ),
                        'desc'    => esc_html__( 'Add Project video link', 'intechcore' ),
                        'default' => esc_html__( 'https://www.youtube.com/watch?v=u8Egk_j0EbY', 'intechcore' ),
                    ),
                ),
            ),
        ),
    );
    $options[] = array(
        'id'        => 'intech_team_meta',
        'title'     => esc_html__( 'Team Options', 'intechcore' ),
        'post_type' => 'team',
        'context'   => 'normal',
        'priority'  => 'high',
        'sections'  => array(
            array(
                'name'   => 'intech_team_options_meta',
                'title'  => esc_html__( 'Project Option MetaBox', 'intechcore' ),
                'fields' => array(
                    array(
                        'id'      => 'intech_team_stitle',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Designation', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Designation here', 'intechcore' ),
                        'default' => esc_html__( 'CEO & Founder ', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_team_age',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Age', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Age here', 'intechcore' ),
                        'default' => esc_html__( '24', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_team_blood',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Blood Group', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Blood Group here', 'intechcore' ),
                        'default' => esc_html__( 'o+', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_team_work_pro',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Work Progress', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Work Progress here', 'intechcore' ),
                        'default' => esc_html__( '100%', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_team_email',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Email', 'intechcore' ),
                        'desc'    => esc_html__( 'Please Type Email here', 'intechcore' ),
                        'default' => esc_html__( 'alex24@example.com', 'intechcore' ),
                    ),

                    array(
                        'id'      => 'intech_team_phone',
                        'type'    => 'text',
                        'title'   => esc_html__( 'Phone Number', 'intechcore' ),
                        'desc'    => esc_html__( 'Add Phone Number Here', 'intechcore' ),
                        'default' => esc_html__( '+555 6666 77 88', 'intechcore' ),
                    ),
                    array(
                        'id'              => 'intech_team_socials',
                        'type'            => 'group',
                        'title'           => esc_html__( 'Team Social', 'intechcore' ),
                        'desc'            => esc_html__( 'Choose your Social media', 'intechcore' ),
                        'button_title'    => esc_html__( 'Add New', 'intechcore' ),
                        'accordion_title' => esc_html__( 'Add New Social Link', 'intechcore' ),
                        'fields'          => array(
                            array(
                                'id'      => 'intech_social_link_text',
                                'type'    => 'text',
                                'title'   => esc_html__( 'Add social Name', 'intechcore' ),
                                'desc'    => esc_html__( 'Please Type your Social Name', 'intechcore' ),
                                'default' => esc_html__( 'Facebook', 'intechcore' ),
                            ),
                            array(
                                'id'      => 'intech_social_link',
                                'type'    => 'text',
                                'title'   => esc_html__( 'Add social link', 'intechcore' ),
                                'desc'    => esc_html__( 'Please Type your Social Link', 'intechcore' ),
                                'default' => esc_html__( '#', 'intechcore' ),
                            ),
                            array(
                                'id'      => 'intech_social_link_icon',
                                'type'    => 'icon',
                                'title'   => esc_html__( 'Add social icon', 'intechcore' ),
                                'desc'    => esc_html__( 'Please Select Social icon', 'intechcore' ),
                                'default' => 'fa fa-facebook',
                            ),
                        ),
                    ),
                ),
            ),
        ),
    );
    // Post formate Metabox
    $options[] = array(
        'id'        => 'intech_pfv_meta',
        'title'     => esc_html__( 'Video Metabox', 'intechcore' ),
        'post_type' => 'post',
        'context'   => 'normal',
        'priority'  => 'high',
        'sections'  => array(
            array(
                'name'   => 'intech_pfv_option_meta',
                'fields' => array(
                    array(
                        'id'    => 'intech_pfv_link',
                        'type'  => 'text',
                        'title' => esc_html__( 'Extranal Video Link', 'intechcore' ),
                        'desc'  => esc_html__( 'Please Add Vimeo or Youtube Video Embed Link Here', 'intechcore' ),
                    ),
                ),
            ),
        ),
    );
    $options[] = array(
        'id'        => 'intech_pfa_meta',
        'title'     => esc_html__( 'Audio Metabox', 'intechcore' ),
        'post_type' => 'post',
        'context'   => 'normal',
        'priority'  => 'high',
        'sections'  => array(
            array(
                'name'   => 'intech_pfa_option_meta',
                'fields' => array(
                    array(
                        'id'    => 'intech_pfa_link',
                        'type'  => 'text',
                        'title' => esc_html__( 'Extranal Audio Link', 'intechcore' ),
                        'desc'  => esc_html__( 'Please Add Extranal Post Audio Link Here', 'intechcore' ),
                    ),
                ),
            ),
        ),
    );
    $options[] = array(
        'id'        => 'intech_pfg_meta',
        'title'     => esc_html__( 'Gallery Metabox', 'intechcore' ),
        'post_type' => 'post',
        'context'   => 'normal',
        'priority'  => 'high',
        'sections'  => array(
            array(
                'name'   => 'intech_pfg_option_meta',
                'fields' => array(
                    array(
                        'id'    => 'intech_pfg_link',
                        'type'  => 'gallery',
                        'title' => esc_html__( 'Extranal Gallery', 'intechcore' ),
                        'desc'  => esc_html__( 'Please Add Extranal Post Gallery Here', 'intechcore' ),
                    ),
                ),
            ),
        ),
    );

/** PAGE META OPTIONS **/
    $options[] = array(
        'id'        => 'intech_page_meta_options',
        'title'     => esc_html__( 'Page Options', 'intechcore' ),
        'post_type' => array( 'page', 'post', 'project', 'team' ),
        'context'   => 'normal',
        'priority'  => 'default',
        'sections'  => array(
            array(
                'name'   => 'intech_page_heaer_options',
                'title'  => esc_html__( 'Header', 'intechcore' ),
                'icon'   => esc_attr__( 'fa fa-map-signs', 'intechcore' ),
                'fields' => array(
                    array(
                        'id'      => 'intech_page_header_enable',
                        'type'    => 'switcher',
                        'title'   => esc_html__( 'Change Header ?', 'intechcore' ),
                        'default' => false,
                    ),
                    array(
                        'id'         => 'intech_page_header_select',
                        'type'       => 'select',
                        'title'      => esc_html__( 'Select Header', 'intechcore' ),
                        'options'    => array(
                            '0' => esc_html__( 'default', 'intechcore' ),
                            '1' => esc_html__( 'Style 1', 'intechcore' ),
                            '2' => esc_html__( 'Style 2', 'intechcore' ),
                            '3' => esc_html__( 'Style 3', 'intechcore' ),
                            '4' => esc_html__( 'Style 4', 'intechcore' ),
                            '5' => esc_html__( 'Style 5', 'intechcore' ),
                            '6' => esc_html__( 'Style 6', 'intechcore' ),
                        ),
                        'default'    => '0',
                        'desc'       => esc_html__( 'if your need change style just select (Yes) options. Default select 1', 'intechcore' ),
                        'dependency' => array( 'intech_page_header_enable', '==', 'true' ),

                    ),
                    array(
                        'id'      => 'intech_page_enable_menu',
                        'type'    => 'switcher',
                        'title'   => esc_html__( 'Enable Menu', 'intechcore' ),
                        'default' => false,
                        'desc'       => esc_html__( 'Show Header Menu if you need', 'intechcore' ),
                    ),
                    array(
                        'id'         => 'intech_page_header_menu',
                        'type'       => 'select',
                        'title'      => esc_html__( 'Select Menu', 'intechcore' ),
                        'options'    => 'menu',
                        'desc'       => esc_html__( 'Select Header Menu', 'intechcore' ),
                        'dependency' => array( 'intech_page_enable_menu', '==', 'true' ),
                    ),

                    array(
                        'id'         => 'intech_header_top_bg',
                        'type'       => 'color_picker',
                        'title'      => esc_html__( 'Header TopBar Background Color', 'intechcore' ),
                        'default'    => '#ffffff',
                        'rgba'       => true,
                        'dependency' => array( 'intech_page_header_select', '==', '2' ),
                    ),
                    array(
                        'id'         => 'intech_header_top_padding',
                        'type'       => 'text',
                        'title'      => esc_html__( 'Header TopBar padding', 'intechcore' ),
                        'default'    => '12px 0',
                        'rgba'       => true,
                        'dependency' => array( 'intech_page_header_select', '==', '2' ),
                    ),
                    array(
                        'id'         => 'intech_main_header_bg',
                        'type'       => 'color_picker',
                        'title'      => esc_html__( 'Header Main Background Color', 'intechcore' ),
                        'default'    => '#0b5be0',
                        'rgba'       => true,
                        'dependency' => array( 'intech_page_header_select', '==', '2' ),
                    ),

                    array(
                        'id'         => 'intech_logo_bg_color',
                        'type'       => 'color_picker',
                        'title'      => esc_html__( 'Logo Background Color', 'intechcore' ),
                        'default'    => '#0b5be0',
                        'rgba'       => true,
                        'dependency' => array( 'intech_page_header_select', '==', '4' ),
                    ),
                    array(
                        'id'         => 'intech_logo_hedigh',
                        'type'       => 'text',
                        'default'    => '132px',
                        'title'      => esc_html__( 'Logo Height', 'intechcore' ),
                        'desc'       => esc_html__( 'Insert custom text for the page title bar.', 'intechcore' ),
                        'dependency' => array( 'intech_page_header_select', '==', '4' ),
                    ),
                    array(
                        'id'         => 'intech_logo_widght',
                        'type'       => 'text',
                        'default'    => '140px',
                        'title'      => esc_html__( 'Logo Widht', 'intechcore' ),
                        'desc'       => esc_html__( 'Add logo area Width', 'intechcore' ),
                        'dependency' => array( 'intech_page_header_select', '==', '4' ),
                    ),
                    array(
                        'id'         => 'intech_logo_bg_color5',
                        'type'       => 'color_picker',
                        'title'      => esc_html__( 'Logo Background Color', 'intechcore' ),
                        'default'    => '#ffffff',
                        'rgba'       => true,
                        'dependency' => array( 'intech_page_header_select', '==', '5' ),
                    ),
                    array(
                        'id'         => 'intech_menu5_color',
                        'type'       => 'color_picker',
                        'title'      => esc_html__( 'Header Text Color', 'intechcore' ),
                        'default'    => '#ffffff',
                        'rgba'       => true,
                        'dependency' => array( 'intech_page_header_select', '==', '5' ),
                    ),
                    array(
                        'id'         => 'intech_menu5_hcolor',
                        'type'       => 'color_picker',
                        'title'      => esc_html__( 'Header Text Hover Color', 'intechcore' ),
                        'default'    => '#000000',
                        'rgba'       => true,
                        'dependency' => array( 'intech_page_header_select', '==', '5' ),
                    ),
                    array(
                        'id'         => 'intech_logo_hedigh5',
                        'type'       => 'text',
                        'default'    => '120px',
                        'title'      => esc_html__( 'Logo Height', 'intechcore' ),
                        'desc'       => esc_html__( 'Insert custom text for the page title bar.', 'intechcore' ),
                        'dependency' => array( 'intech_page_header_select', '==', '5' ),
                    ),
                    array(
                        'id'         => 'intech_logo_widght5',
                        'type'       => 'text',
                        'default'    => '120px',
                        'title'      => esc_html__( 'Logo Widht', 'intechcore' ),
                        'desc'       => esc_html__( 'Add logo area Width', 'intechcore' ),
                        'dependency' => array( 'intech_page_header_select', '==', '5' ),
                    ),
                    array(
                        'id'      => 'intech_header6_position',
                        'type'    => 'select',
                        'title'   => esc_html__( 'Select Options', 'intechcore' ),
                        'options' => array(
                            'absolute' => esc_html__('Absolute','intechcore'),
                            'relative' => esc_html__('Relative','intechcore'),
                        ),
                        'default' => 'relative',
                    ),
                    array(
                        'id'      => 'intech_header6_menu_c',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Menu Color', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Menu Color', 'intechcore' ),
                        'rgba'    => true,
                    ),
                    array(
                        'id'      => 'intech_header6_menu_hc',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Menu Hover Color', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Menu Hover Color', 'intechcore' ),
                        'rgba'    => true,
                    ),
                    array(
                        'id'      => 'intech_header6_bg',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Header Background', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Background Color', 'intechcore' ),
                        'rgba'    => true,
                        'dependency' => array( 'intech_page_header_select', '==', '6' ),
                    ),
                    array(
                        'id'      => 'intech_header6_sticky_bg',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Header Sticky Background', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Background Color', 'intechcore' ),
                        'rgba'    => true,
                        'dependency' => array( 'intech_page_header_select', '==', '6' ),
                    ),
                    array(
                        'id'      => 'intech_header6_btn_bg',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Button Background', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Button Background Color', 'intechcore' ),
                        'rgba'    => true,
                        'dependency' => array( 'intech_page_header_select', '==', '6' ),
                    ),
                    array(
                        'id'      => 'intech_header6_btn_hbg',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Button Hover Background', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Button Hover Background Color', 'intechcore' ),
                        'rgba'    => true,
                        'dependency' => array( 'intech_page_header_select', '==', '6' ),
                    ),
                    array(
                        'id'      => 'intech_header6_btn_border_c',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Button Border Color', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Button Border Color', 'intechcore' ),
                        'rgba'    => true,
                        'dependency' => array( 'intech_page_header_select', '==', '6' ),
                    ),
                    array(
                        'id'      => 'intech_header6_btn_border_hc',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Button Border Hover Color', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Button Border Hover Color', 'intechcore' ),
                        'rgba'    => true,
                        'dependency' => array( 'intech_page_header_select', '==', '6' ),
                    ),
                    array(
                        'id'      => 'intech_header6_btn_text_c',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Button Text Color', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Button Text Color', 'intechcore' ),
                        'rgba'    => true,
                        'dependency' => array( 'intech_page_header_select', '==', '6' ),
                    ),
                    array(
                        'id'      => 'intech_header6_btn_text_hc',
                        'type'    => 'color_picker',
                        'title'   => esc_html__( 'Button Text Hover Color', 'intechcore' ),
                        'desc'       => esc_html__( 'Add Header Six Button Text Hover Color', 'intechcore' ),
                        'rgba'    => true,
                        'dependency' => array( 'intech_page_header_select', '==', '6' ),
                    ),





                    array(
                        'type'    => 'subheading',
                        'content' => esc_html__( 'Logo Upload Options', 'intechcore' ),
                    ),
                    array(
                        'id'      => 'intech_page_logo_enable',
                        'title'   => esc_html__( 'Enable Uplod Logo ?', 'intechcore' ),
                        'type'    => 'switcher',
                        'default' => false,
                        'desc'    => esc_html__( 'Choose to show or hide Options', 'intechcore' ),
                    ),
                    array(
                        'id'         => 'intech_page_logo_upload',
                        'type'       => 'image',
                        'title'      => esc_html__( 'Upload Logo', 'intechcore' ),
                        'add_title'  => esc_html__( 'Add Logo', 'intechcore' ),
                        'dependency' => array( 'intech_page_logo_enable', '==', 'true' ),
                    ),
                ),
            ),
            array(
                'name'   => 'intech_page_title_bar',
                'title'  => esc_html__( 'Page Title Bar', 'intechcore' ),
                'icon'   => esc_attr__( 'fa fa-map-signs', 'intechcore' ),
                'fields' => array(
                    array(
                        'id'      => 'intech_page_title_enable',
                        'title'   => esc_html__( 'Page Title Enable', 'intechcore' ),
                        'type'    => 'switcher',
                        'default' => true,
                        'desc'    => esc_html__( 'Choose to show or hide the page title bar', 'intechcore' ),
                    ),
                    array(
                        'id'         => 'intech_custom_page_title',
                        'type'       => 'text',
                        'title'      => esc_html__( 'Custom page title bar.', 'intechcore' ),
                        'desc'       => esc_html__( 'Insert custom text for the page title bar.', 'intechcore' ),
                        'dependency' => array( 'intech_page_title_enable', '==', 'true' ),
                    ),
                ),
            ),
            array(
                'name'   => 'intech_page_footer_options',
                'title'  => esc_html__( 'Footer Settings', 'intechcore' ),
                'icon'   => esc_attr__( 'fa fa-map-signs', 'intechcore' ),
                'fields' => array(
                    array(
                        'id'      => 'intech_page_ft_enable',
                        'type'    => 'switcher',
                        'title'   => esc_html__( 'Do you need Change Footer ?', 'intechcore' ),
                        'default' => false,
                    ),
                    array(
                        'id'         => 'intech_page_ft_select',
                        'type'       => 'select',
                        'title'      => esc_html__( 'Select Header', 'intechcore' ),
                        'options'    => array(
                            'none' => esc_html__( 'Default', 'intechcore' ),
                            'one' => esc_html__( 'Footer One', 'intechcore' ),
                            'two' => esc_html__( 'Footer Two', 'intechcore' ),
                            'three' => esc_html__( 'Footer Three', 'intechcore' ),
                        ),
                        'default'    => 'none',
                        'desc'       => esc_html__( 'if your need change style just select (Yes) options. Default select One', 'intechcore' ),
                        'dependency' => array( 'intech_page_ft_enable', '==', 'true' ),

                    ),
                ),
            ),
        ),
    );
    return $options;
}
add_filter( 'cs_metabox_options', 'intech_post_metabox' );
