<?php 
add_action( 'init', 'intechcore_custom_post_type' );
function intechcore_custom_post_type() {
    register_post_type( 'project',
        array(
            'labels' => array(
                'name' => esc_html__('projects','intechcore'),
                'singular_name' => esc_html__('Project','intechcore'),
            ),
            'show_in_rest'  => true,
            'supports'      => array('title','thumbnail', 'page-attributes','editor','excerpt'),
            'menu_icon'     => esc_attr__('dashicons-image-filter','intechcore'),
            'public'        => true
        )
    );
    register_post_type( 'team',
        array(
            'labels' => array(
                'name' => esc_html__('team','intechcore'),
                'singular_name' => esc_html__('Team','intechcore'),
            ),
            'show_in_rest'  => true,
            'supports'      => array('title','thumbnail','editor','excerpt'),
            'menu_icon'     => esc_attr__('dashicons-groups','intechcore'),
            'public'        => true,
            'has_archive' => true,
            'hierarchical' => false,
            'exclude_from_search' => false,
            'publicly_queryable' => true,
            'capability_type' => 'post',
        )
    );
}
/*** Custom taxonomy ***/
add_action( 'init', 'intechcore_custom_post_taxonomy');
function intechcore_custom_post_taxonomy() {
    register_taxonomy(
        'project_cat',
        'project',                  
            array(
                'label'                 => esc_html__('project Category', 'intechcore'),
                'query_var'             => true,
                'hierarchical'          => true,
                'public'                => true,
                'show_ui'               => true,
                'show_admin_column'     => false,
                'show_in_nav_menus'     => true,
                'show_in_rest'          => true,
                'show_tagcloud'         => true,
                'rewrite'               => array(
                    'slug'              => 'project-category', 
                    'with_front'        => true 
                )
            )
    );
}